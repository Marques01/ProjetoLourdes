﻿namespace Empresa2
{
    partial class manutencao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(manutencao));
            this.txtData = new System.Windows.Forms.TextBox();
            this.lblData = new System.Windows.Forms.Label();
            this.txtModelo = new System.Windows.Forms.TextBox();
            this.lblNordem = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.txtAvariaA = new System.Windows.Forms.TextBox();
            this.lblAvaria = new System.Windows.Forms.Label();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.picAjudaAvaria = new System.Windows.Forms.PictureBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.combNordem = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlLDAR = new System.Windows.Forms.Panel();
            this.lblChapa6AR = new System.Windows.Forms.Label();
            this.lblChapa5AR = new System.Windows.Forms.Label();
            this.lblChapa4AR = new System.Windows.Forms.Label();
            this.lblChapa3AR = new System.Windows.Forms.Label();
            this.lblChapa2AR = new System.Windows.Forms.Label();
            this.lblChapa17AR = new System.Windows.Forms.Label();
            this.lblChapa16AR = new System.Windows.Forms.Label();
            this.lblChapa15AR = new System.Windows.Forms.Label();
            this.lblChapa14AR = new System.Windows.Forms.Label();
            this.lblChapa13AR = new System.Windows.Forms.Label();
            this.lblChapa12AR = new System.Windows.Forms.Label();
            this.lblChapa11AR = new System.Windows.Forms.Label();
            this.lblChapa10AR = new System.Windows.Forms.Label();
            this.lblChapa9AR = new System.Windows.Forms.Label();
            this.lblChapa8AR = new System.Windows.Forms.Label();
            this.lblChapa7AR = new System.Windows.Forms.Label();
            this.lblColunaTDAR = new System.Windows.Forms.Label();
            this.lblChapa1AR = new System.Windows.Forms.Label();
            this.pnlLEAR = new System.Windows.Forms.Panel();
            this.lblColunaTEAR = new System.Windows.Forms.Label();
            this.lblChapa18LEAR = new System.Windows.Forms.Label();
            this.lblChapa17LEAR = new System.Windows.Forms.Label();
            this.lblChapa16LEAR = new System.Windows.Forms.Label();
            this.lblChapa15LEAR = new System.Windows.Forms.Label();
            this.lblChapa14LEAR = new System.Windows.Forms.Label();
            this.lblChapa13LEAR = new System.Windows.Forms.Label();
            this.lblChapa12LEAR = new System.Windows.Forms.Label();
            this.lblChapa11LEAR = new System.Windows.Forms.Label();
            this.lblChapa10LEAR = new System.Windows.Forms.Label();
            this.lblChapa9LEAR = new System.Windows.Forms.Label();
            this.lblChapa8LEAR = new System.Windows.Forms.Label();
            this.lblChapa7LEAR = new System.Windows.Forms.Label();
            this.lblChapa6LEAR = new System.Windows.Forms.Label();
            this.lblChapa5LEAR = new System.Windows.Forms.Label();
            this.lblChapa4LEAR = new System.Windows.Forms.Label();
            this.lblChapa3LEAR = new System.Windows.Forms.Label();
            this.lblChapa2LEAR = new System.Windows.Forms.Label();
            this.lblChapa1LEAR = new System.Windows.Forms.Label();
            this.pnlDianteira = new System.Windows.Forms.Panel();
            this.lblPonteiraDDAR = new System.Windows.Forms.Label();
            this.lblParachoqueDAR = new System.Windows.Forms.Label();
            this.lblPonteiraDEAR = new System.Windows.Forms.Label();
            this.lblGradeAR = new System.Windows.Forms.Label();
            this.pnlTraseira = new System.Windows.Forms.Panel();
            this.lblColunaTD2 = new System.Windows.Forms.Label();
            this.lblPonteiraTD = new System.Windows.Forms.Label();
            this.lblParachoqueT = new System.Windows.Forms.Label();
            this.lblPonteiraTE = new System.Windows.Forms.Label();
            this.lblColunaTE1 = new System.Windows.Forms.Label();
            this.lblTraseiraM = new System.Windows.Forms.Label();
            this.btnNovaAvaria = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picAjudaAvaria)).BeginInit();
            this.pnlLDAR.SuspendLayout();
            this.pnlLEAR.SuspendLayout();
            this.pnlDianteira.SuspendLayout();
            this.pnlTraseira.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtData
            // 
            this.txtData.BackColor = System.Drawing.Color.FloralWhite;
            this.txtData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtData.Location = new System.Drawing.Point(877, 720);
            this.txtData.Name = "txtData";
            this.txtData.ReadOnly = true;
            this.txtData.Size = new System.Drawing.Size(123, 26);
            this.txtData.TabIndex = 3;
            this.txtData.Visible = false;
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.BackColor = System.Drawing.Color.Transparent;
            this.lblData.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData.ForeColor = System.Drawing.Color.White;
            this.lblData.Location = new System.Drawing.Point(881, 692);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(72, 25);
            this.lblData.TabIndex = 4;
            this.lblData.Text = "DATA";
            this.lblData.Visible = false;
            // 
            // txtModelo
            // 
            this.txtModelo.Enabled = false;
            this.txtModelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModelo.Location = new System.Drawing.Point(7, 533);
            this.txtModelo.MaxLength = 5;
            this.txtModelo.Name = "txtModelo";
            this.txtModelo.ReadOnly = true;
            this.txtModelo.Size = new System.Drawing.Size(216, 26);
            this.txtModelo.TabIndex = 0;
            this.txtModelo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblNordem
            // 
            this.lblNordem.AutoSize = true;
            this.lblNordem.BackColor = System.Drawing.Color.Transparent;
            this.lblNordem.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNordem.ForeColor = System.Drawing.Color.White;
            this.lblNordem.Location = new System.Drawing.Point(6, 562);
            this.lblNordem.Name = "lblNordem";
            this.lblNordem.Size = new System.Drawing.Size(113, 25);
            this.lblNordem.TabIndex = 4;
            this.lblNordem.Text = "Nº Ordem";
            // 
            // txtAvariaA
            // 
            this.txtAvariaA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAvariaA.Location = new System.Drawing.Point(7, 644);
            this.txtAvariaA.MaxLength = 9999;
            this.txtAvariaA.Name = "txtAvariaA";
            this.txtAvariaA.Size = new System.Drawing.Size(216, 26);
            this.txtAvariaA.TabIndex = 1;
            // 
            // lblAvaria
            // 
            this.lblAvaria.AutoSize = true;
            this.lblAvaria.BackColor = System.Drawing.Color.Transparent;
            this.lblAvaria.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvaria.ForeColor = System.Drawing.Color.White;
            this.lblAvaria.Location = new System.Drawing.Point(11, 616);
            this.lblAvaria.Name = "lblAvaria";
            this.lblAvaria.Size = new System.Drawing.Size(79, 25);
            this.lblAvaria.TabIndex = 4;
            this.lblAvaria.Text = "Avaria";
            // 
            // btnSalvar
            // 
            this.btnSalvar.FlatAppearance.BorderSize = 0;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvar.Location = new System.Drawing.Point(7, 715);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(105, 30);
            this.btnSalvar.TabIndex = 2;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // picAjudaAvaria
            // 
            this.picAjudaAvaria.BackColor = System.Drawing.Color.Transparent;
            this.picAjudaAvaria.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picAjudaAvaria.Image = global::Empresa2.Properties.Resources.Help_icon_icons_com_73700;
            this.picAjudaAvaria.Location = new System.Drawing.Point(226, 644);
            this.picAjudaAvaria.Name = "picAjudaAvaria";
            this.picAjudaAvaria.Size = new System.Drawing.Size(26, 26);
            this.picAjudaAvaria.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picAjudaAvaria.TabIndex = 53;
            this.picAjudaAvaria.TabStop = false;
            // 
            // btnLimpar
            // 
            this.btnLimpar.FlatAppearance.BorderSize = 0;
            this.btnLimpar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.btnLimpar.Location = new System.Drawing.Point(118, 679);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(105, 30);
            this.btnLimpar.TabIndex = 3;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.GreenYellow;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(979, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 20);
            this.label1.TabIndex = 60;
            this.label1.Text = "X";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // combNordem
            // 
            this.combNordem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combNordem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.combNordem.FormattingEnabled = true;
            this.combNordem.Items.AddRange(new object[] {
            "",
            "58001",
            "58003",
            "58006",
            "58007",
            "58008",
            "58009",
            "58010",
            "58011",
            "58012",
            "58013",
            "58014",
            "58016",
            "58017",
            "58019",
            "58020",
            "58022",
            "58023",
            "58024",
            "58025",
            "58027",
            "58028",
            "58031",
            "58032",
            "58033",
            "58034",
            "58035",
            "58039",
            "58040",
            "58042",
            "58043",
            "58044",
            "58046",
            "58047",
            "58048",
            "58049",
            "58052",
            "58053",
            "58054",
            "58055",
            "58056",
            "58058",
            "58059",
            "58060",
            "58061",
            "58063",
            "58065",
            "58070",
            "58073",
            "58075",
            "58076",
            "58077",
            "58078",
            "58079",
            "58081",
            "58084",
            "58085",
            "58088",
            "58089",
            "58091",
            "58092",
            "58094",
            "58095",
            "58096",
            "58097",
            "58098",
            "58100",
            "58102",
            "58103",
            "58105",
            "58106",
            "58110",
            "58111",
            "58113",
            "58114",
            "58115",
            "58116",
            "58117",
            "58118",
            "58119",
            "58120",
            "58121",
            "58122",
            "58123",
            "58124",
            "58125",
            "58127",
            "58128",
            "58131",
            "58132",
            "58135",
            "58147",
            "58150",
            "58151",
            "58152",
            "58153",
            "58155",
            "58157",
            "58160",
            "58161",
            "58162",
            "58163",
            "58164",
            "58165",
            "58166",
            "58167",
            "58168",
            "58169",
            "58171",
            "58172",
            "58173",
            "58174",
            "58177",
            "58178",
            "58185",
            "58188",
            "58189",
            "58190",
            "58204",
            "58205",
            "58207",
            "58210",
            "58211",
            "58214",
            "58215",
            "58216",
            "58217"});
            this.combNordem.Location = new System.Drawing.Point(7, 589);
            this.combNordem.Name = "combNordem";
            this.combNordem.Size = new System.Drawing.Size(216, 28);
            this.combNordem.TabIndex = 0;
            this.combNordem.SelectedIndexChanged += new System.EventHandler(this.combNordem_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(11, 505);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 25);
            this.label2.TabIndex = 62;
            this.label2.Text = "Modelo";
            // 
            // pnlLDAR
            // 
            this.pnlLDAR.BackColor = System.Drawing.Color.Transparent;
            this.pnlLDAR.Controls.Add(this.lblChapa6AR);
            this.pnlLDAR.Controls.Add(this.lblChapa5AR);
            this.pnlLDAR.Controls.Add(this.lblChapa4AR);
            this.pnlLDAR.Controls.Add(this.lblChapa3AR);
            this.pnlLDAR.Controls.Add(this.lblChapa2AR);
            this.pnlLDAR.Controls.Add(this.lblChapa17AR);
            this.pnlLDAR.Controls.Add(this.lblChapa16AR);
            this.pnlLDAR.Controls.Add(this.lblChapa15AR);
            this.pnlLDAR.Controls.Add(this.lblChapa14AR);
            this.pnlLDAR.Controls.Add(this.lblChapa13AR);
            this.pnlLDAR.Controls.Add(this.lblChapa12AR);
            this.pnlLDAR.Controls.Add(this.lblChapa11AR);
            this.pnlLDAR.Controls.Add(this.lblChapa10AR);
            this.pnlLDAR.Controls.Add(this.lblChapa9AR);
            this.pnlLDAR.Controls.Add(this.lblChapa8AR);
            this.pnlLDAR.Controls.Add(this.lblChapa7AR);
            this.pnlLDAR.Controls.Add(this.lblColunaTDAR);
            this.pnlLDAR.Controls.Add(this.lblChapa1AR);
            this.pnlLDAR.Location = new System.Drawing.Point(13, 112);
            this.pnlLDAR.Name = "pnlLDAR";
            this.pnlLDAR.Size = new System.Drawing.Size(749, 129);
            this.pnlLDAR.TabIndex = 63;
            // 
            // lblChapa6AR
            // 
            this.lblChapa6AR.AutoSize = true;
            this.lblChapa6AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa6AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa6AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa6AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa6AR.Location = new System.Drawing.Point(75, 75);
            this.lblChapa6AR.Name = "lblChapa6AR";
            this.lblChapa6AR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa6AR.TabIndex = 64;
            this.lblChapa6AR.Text = "6";
            this.lblChapa6AR.Click += new System.EventHandler(this.lblChapa6AR_Click);
            // 
            // lblChapa5AR
            // 
            this.lblChapa5AR.AutoSize = true;
            this.lblChapa5AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa5AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa5AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa5AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa5AR.Location = new System.Drawing.Point(550, 29);
            this.lblChapa5AR.Name = "lblChapa5AR";
            this.lblChapa5AR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa5AR.TabIndex = 64;
            this.lblChapa5AR.Text = "5";
            this.lblChapa5AR.Click += new System.EventHandler(this.lblChapa5AR_Click);
            // 
            // lblChapa4AR
            // 
            this.lblChapa4AR.AutoSize = true;
            this.lblChapa4AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa4AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa4AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa4AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa4AR.Location = new System.Drawing.Point(442, 29);
            this.lblChapa4AR.Name = "lblChapa4AR";
            this.lblChapa4AR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa4AR.TabIndex = 64;
            this.lblChapa4AR.Text = "4";
            this.lblChapa4AR.Click += new System.EventHandler(this.lblChapa4AR_Click);
            // 
            // lblChapa3AR
            // 
            this.lblChapa3AR.AutoSize = true;
            this.lblChapa3AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa3AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa3AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa3AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa3AR.Location = new System.Drawing.Point(259, 29);
            this.lblChapa3AR.Name = "lblChapa3AR";
            this.lblChapa3AR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa3AR.TabIndex = 64;
            this.lblChapa3AR.Text = "3";
            this.lblChapa3AR.Click += new System.EventHandler(this.lblChapa3AR_Click);
            // 
            // lblChapa2AR
            // 
            this.lblChapa2AR.AutoSize = true;
            this.lblChapa2AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa2AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa2AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa2AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa2AR.Location = new System.Drawing.Point(164, 29);
            this.lblChapa2AR.Name = "lblChapa2AR";
            this.lblChapa2AR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa2AR.TabIndex = 64;
            this.lblChapa2AR.Text = "2";
            this.lblChapa2AR.Click += new System.EventHandler(this.lblChapa2AR_Click);
            // 
            // lblChapa17AR
            // 
            this.lblChapa17AR.AutoSize = true;
            this.lblChapa17AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa17AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa17AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa17AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa17AR.Location = new System.Drawing.Point(332, 61);
            this.lblChapa17AR.Name = "lblChapa17AR";
            this.lblChapa17AR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa17AR.TabIndex = 64;
            this.lblChapa17AR.Text = "17";
            this.lblChapa17AR.Click += new System.EventHandler(this.lblChapa17AR_Click);
            // 
            // lblChapa16AR
            // 
            this.lblChapa16AR.AutoSize = true;
            this.lblChapa16AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa16AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa16AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa16AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa16AR.Location = new System.Drawing.Point(374, 29);
            this.lblChapa16AR.Name = "lblChapa16AR";
            this.lblChapa16AR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa16AR.TabIndex = 64;
            this.lblChapa16AR.Text = "16";
            this.lblChapa16AR.Click += new System.EventHandler(this.lblChapa16AR_Click);
            // 
            // lblChapa15AR
            // 
            this.lblChapa15AR.AutoSize = true;
            this.lblChapa15AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa15AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa15AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa15AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa15AR.Location = new System.Drawing.Point(716, 81);
            this.lblChapa15AR.Name = "lblChapa15AR";
            this.lblChapa15AR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa15AR.TabIndex = 64;
            this.lblChapa15AR.Text = "15";
            this.lblChapa15AR.Click += new System.EventHandler(this.lblChapa15AR_Click);
            // 
            // lblChapa14AR
            // 
            this.lblChapa14AR.AutoSize = true;
            this.lblChapa14AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa14AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa14AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa14AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa14AR.Location = new System.Drawing.Point(630, 64);
            this.lblChapa14AR.Name = "lblChapa14AR";
            this.lblChapa14AR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa14AR.TabIndex = 64;
            this.lblChapa14AR.Text = "14";
            this.lblChapa14AR.Click += new System.EventHandler(this.lblChapa14AR_Click);
            // 
            // lblChapa13AR
            // 
            this.lblChapa13AR.AutoSize = true;
            this.lblChapa13AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa13AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa13AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa13AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa13AR.Location = new System.Drawing.Point(537, 68);
            this.lblChapa13AR.Name = "lblChapa13AR";
            this.lblChapa13AR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa13AR.TabIndex = 64;
            this.lblChapa13AR.Text = "13";
            this.lblChapa13AR.Click += new System.EventHandler(this.lblChapa13AR_Click);
            // 
            // lblChapa12AR
            // 
            this.lblChapa12AR.AutoSize = true;
            this.lblChapa12AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa12AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa12AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa12AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa12AR.Location = new System.Drawing.Point(491, 87);
            this.lblChapa12AR.Name = "lblChapa12AR";
            this.lblChapa12AR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa12AR.TabIndex = 64;
            this.lblChapa12AR.Text = "12";
            this.lblChapa12AR.Click += new System.EventHandler(this.lblChapa12AR_Click);
            // 
            // lblChapa11AR
            // 
            this.lblChapa11AR.AutoSize = true;
            this.lblChapa11AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa11AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa11AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa11AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa11AR.Location = new System.Drawing.Point(430, 87);
            this.lblChapa11AR.Name = "lblChapa11AR";
            this.lblChapa11AR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa11AR.TabIndex = 64;
            this.lblChapa11AR.Text = "11";
            this.lblChapa11AR.Click += new System.EventHandler(this.lblChapa11AR_Click);
            // 
            // lblChapa10AR
            // 
            this.lblChapa10AR.AutoSize = true;
            this.lblChapa10AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa10AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa10AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa10AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa10AR.Location = new System.Drawing.Point(374, 87);
            this.lblChapa10AR.Name = "lblChapa10AR";
            this.lblChapa10AR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa10AR.TabIndex = 64;
            this.lblChapa10AR.Text = "10";
            this.lblChapa10AR.Click += new System.EventHandler(this.lblChapa10AR_Click);
            // 
            // lblChapa9AR
            // 
            this.lblChapa9AR.AutoSize = true;
            this.lblChapa9AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa9AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa9AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa9AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa9AR.Location = new System.Drawing.Point(332, 87);
            this.lblChapa9AR.Name = "lblChapa9AR";
            this.lblChapa9AR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa9AR.TabIndex = 64;
            this.lblChapa9AR.Text = "9";
            this.lblChapa9AR.Click += new System.EventHandler(this.lblChapa9AR_Click);
            // 
            // lblChapa8AR
            // 
            this.lblChapa8AR.AutoSize = true;
            this.lblChapa8AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa8AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa8AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa8AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa8AR.Location = new System.Drawing.Point(285, 75);
            this.lblChapa8AR.Name = "lblChapa8AR";
            this.lblChapa8AR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa8AR.TabIndex = 64;
            this.lblChapa8AR.Text = "8";
            this.lblChapa8AR.Click += new System.EventHandler(this.lblChapa8AR_Click);
            // 
            // lblChapa7AR
            // 
            this.lblChapa7AR.AutoSize = true;
            this.lblChapa7AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa7AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa7AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa7AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa7AR.Location = new System.Drawing.Point(150, 75);
            this.lblChapa7AR.Name = "lblChapa7AR";
            this.lblChapa7AR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa7AR.TabIndex = 64;
            this.lblChapa7AR.Text = "7";
            this.lblChapa7AR.Click += new System.EventHandler(this.lblChapa7AR_Click);
            // 
            // lblColunaTDAR
            // 
            this.lblColunaTDAR.AutoSize = true;
            this.lblColunaTDAR.BackColor = System.Drawing.Color.Transparent;
            this.lblColunaTDAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblColunaTDAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColunaTDAR.ForeColor = System.Drawing.Color.Black;
            this.lblColunaTDAR.Location = new System.Drawing.Point(3, 29);
            this.lblColunaTDAR.Name = "lblColunaTDAR";
            this.lblColunaTDAR.Size = new System.Drawing.Size(24, 25);
            this.lblColunaTDAR.TabIndex = 64;
            this.lblColunaTDAR.Text = "0";
            this.lblColunaTDAR.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblChapa1AR
            // 
            this.lblChapa1AR.AutoSize = true;
            this.lblChapa1AR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa1AR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa1AR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapa1AR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa1AR.Location = new System.Drawing.Point(75, 29);
            this.lblChapa1AR.Name = "lblChapa1AR";
            this.lblChapa1AR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa1AR.TabIndex = 64;
            this.lblChapa1AR.Text = "1";
            this.lblChapa1AR.Click += new System.EventHandler(this.label3_Click);
            // 
            // pnlLEAR
            // 
            this.pnlLEAR.BackColor = System.Drawing.Color.Transparent;
            this.pnlLEAR.Controls.Add(this.lblColunaTEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa18LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa17LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa16LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa15LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa14LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa13LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa12LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa11LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa10LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa9LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa8LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa7LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa6LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa5LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa4LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa3LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa2LEAR);
            this.pnlLEAR.Controls.Add(this.lblChapa1LEAR);
            this.pnlLEAR.Location = new System.Drawing.Point(16, 389);
            this.pnlLEAR.Name = "pnlLEAR";
            this.pnlLEAR.Size = new System.Drawing.Size(761, 100);
            this.pnlLEAR.TabIndex = 64;
            // 
            // lblColunaTEAR
            // 
            this.lblColunaTEAR.AutoSize = true;
            this.lblColunaTEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblColunaTEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblColunaTEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblColunaTEAR.ForeColor = System.Drawing.Color.Black;
            this.lblColunaTEAR.Location = new System.Drawing.Point(715, 33);
            this.lblColunaTEAR.Name = "lblColunaTEAR";
            this.lblColunaTEAR.Size = new System.Drawing.Size(36, 25);
            this.lblColunaTEAR.TabIndex = 65;
            this.lblColunaTEAR.Text = "19";
            this.lblColunaTEAR.Click += new System.EventHandler(this.lblColunaTEAR_Click);
            // 
            // lblChapa18LEAR
            // 
            this.lblChapa18LEAR.AutoSize = true;
            this.lblChapa18LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa18LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa18LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa18LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa18LEAR.Location = new System.Drawing.Point(715, 8);
            this.lblChapa18LEAR.Name = "lblChapa18LEAR";
            this.lblChapa18LEAR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa18LEAR.TabIndex = 65;
            this.lblChapa18LEAR.Text = "18";
            this.lblChapa18LEAR.Click += new System.EventHandler(this.lblChapa18LEAR_Click);
            // 
            // lblChapa17LEAR
            // 
            this.lblChapa17LEAR.AutoSize = true;
            this.lblChapa17LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa17LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa17LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa17LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa17LEAR.Location = new System.Drawing.Point(715, 64);
            this.lblChapa17LEAR.Name = "lblChapa17LEAR";
            this.lblChapa17LEAR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa17LEAR.TabIndex = 65;
            this.lblChapa17LEAR.Text = "17";
            this.lblChapa17LEAR.Click += new System.EventHandler(this.lblChapa17LE_Click);
            // 
            // lblChapa16LEAR
            // 
            this.lblChapa16LEAR.AutoSize = true;
            this.lblChapa16LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa16LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa16LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa16LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa16LEAR.Location = new System.Drawing.Point(631, 64);
            this.lblChapa16LEAR.Name = "lblChapa16LEAR";
            this.lblChapa16LEAR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa16LEAR.TabIndex = 65;
            this.lblChapa16LEAR.Text = "16";
            this.lblChapa16LEAR.Click += new System.EventHandler(this.lblChapa16LEAR_Click);
            // 
            // lblChapa15LEAR
            // 
            this.lblChapa15LEAR.AutoSize = true;
            this.lblChapa15LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa15LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa15LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa15LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa15LEAR.Location = new System.Drawing.Point(567, 64);
            this.lblChapa15LEAR.Name = "lblChapa15LEAR";
            this.lblChapa15LEAR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa15LEAR.TabIndex = 65;
            this.lblChapa15LEAR.Text = "15";
            this.lblChapa15LEAR.Click += new System.EventHandler(this.lblChapa15LEAR_Click);
            // 
            // lblChapa14LEAR
            // 
            this.lblChapa14LEAR.AutoSize = true;
            this.lblChapa14LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa14LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa14LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa14LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa14LEAR.Location = new System.Drawing.Point(439, 64);
            this.lblChapa14LEAR.Name = "lblChapa14LEAR";
            this.lblChapa14LEAR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa14LEAR.TabIndex = 65;
            this.lblChapa14LEAR.Text = "14";
            this.lblChapa14LEAR.Click += new System.EventHandler(this.lblChapa14LEAR_Click);
            // 
            // lblChapa13LEAR
            // 
            this.lblChapa13LEAR.AutoSize = true;
            this.lblChapa13LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa13LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa13LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa13LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa13LEAR.Location = new System.Drawing.Point(341, 64);
            this.lblChapa13LEAR.Name = "lblChapa13LEAR";
            this.lblChapa13LEAR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa13LEAR.TabIndex = 65;
            this.lblChapa13LEAR.Text = "13";
            this.lblChapa13LEAR.Click += new System.EventHandler(this.lblChapa13LEAR_Click);
            // 
            // lblChapa12LEAR
            // 
            this.lblChapa12LEAR.AutoSize = true;
            this.lblChapa12LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa12LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa12LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa12LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa12LEAR.Location = new System.Drawing.Point(270, 64);
            this.lblChapa12LEAR.Name = "lblChapa12LEAR";
            this.lblChapa12LEAR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa12LEAR.TabIndex = 65;
            this.lblChapa12LEAR.Text = "12";
            this.lblChapa12LEAR.Click += new System.EventHandler(this.lblChapa12LE_Click);
            // 
            // lblChapa11LEAR
            // 
            this.lblChapa11LEAR.AutoSize = true;
            this.lblChapa11LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa11LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa11LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa11LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa11LEAR.Location = new System.Drawing.Point(217, 64);
            this.lblChapa11LEAR.Name = "lblChapa11LEAR";
            this.lblChapa11LEAR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa11LEAR.TabIndex = 65;
            this.lblChapa11LEAR.Text = "11";
            this.lblChapa11LEAR.Click += new System.EventHandler(this.lblChapa11LEAR_Click);
            // 
            // lblChapa10LEAR
            // 
            this.lblChapa10LEAR.AutoSize = true;
            this.lblChapa10LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa10LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa10LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa10LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa10LEAR.Location = new System.Drawing.Point(183, 64);
            this.lblChapa10LEAR.Name = "lblChapa10LEAR";
            this.lblChapa10LEAR.Size = new System.Drawing.Size(36, 25);
            this.lblChapa10LEAR.TabIndex = 65;
            this.lblChapa10LEAR.Text = "10";
            this.lblChapa10LEAR.Click += new System.EventHandler(this.lblChapa10LEAR_Click);
            // 
            // lblChapa9LEAR
            // 
            this.lblChapa9LEAR.AutoSize = true;
            this.lblChapa9LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa9LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa9LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa9LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa9LEAR.Location = new System.Drawing.Point(79, 64);
            this.lblChapa9LEAR.Name = "lblChapa9LEAR";
            this.lblChapa9LEAR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa9LEAR.TabIndex = 65;
            this.lblChapa9LEAR.Text = "9";
            this.lblChapa9LEAR.Click += new System.EventHandler(this.lblChapa9LEAR_Click);
            // 
            // lblChapa8LEAR
            // 
            this.lblChapa8LEAR.AutoSize = true;
            this.lblChapa8LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa8LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa8LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa8LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa8LEAR.Location = new System.Drawing.Point(43, 64);
            this.lblChapa8LEAR.Name = "lblChapa8LEAR";
            this.lblChapa8LEAR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa8LEAR.TabIndex = 65;
            this.lblChapa8LEAR.Text = "8";
            this.lblChapa8LEAR.Click += new System.EventHandler(this.lblChapa8LEAR_Click);
            // 
            // lblChapa7LEAR
            // 
            this.lblChapa7LEAR.AutoSize = true;
            this.lblChapa7LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa7LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa7LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa7LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa7LEAR.Location = new System.Drawing.Point(643, 19);
            this.lblChapa7LEAR.Name = "lblChapa7LEAR";
            this.lblChapa7LEAR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa7LEAR.TabIndex = 65;
            this.lblChapa7LEAR.Text = "7";
            this.lblChapa7LEAR.Click += new System.EventHandler(this.lblChapa7LEAR_Click);
            // 
            // lblChapa6LEAR
            // 
            this.lblChapa6LEAR.AutoSize = true;
            this.lblChapa6LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa6LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa6LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa6LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa6LEAR.Location = new System.Drawing.Point(531, 19);
            this.lblChapa6LEAR.Name = "lblChapa6LEAR";
            this.lblChapa6LEAR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa6LEAR.TabIndex = 65;
            this.lblChapa6LEAR.Text = "6";
            this.lblChapa6LEAR.Click += new System.EventHandler(this.lblChapa6LEAR_Click);
            // 
            // lblChapa5LEAR
            // 
            this.lblChapa5LEAR.AutoSize = true;
            this.lblChapa5LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa5LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa5LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa5LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa5LEAR.Location = new System.Drawing.Point(424, 19);
            this.lblChapa5LEAR.Name = "lblChapa5LEAR";
            this.lblChapa5LEAR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa5LEAR.TabIndex = 65;
            this.lblChapa5LEAR.Text = "5";
            this.lblChapa5LEAR.Click += new System.EventHandler(this.lblChapa5LEAR_Click);
            // 
            // lblChapa4LEAR
            // 
            this.lblChapa4LEAR.AutoSize = true;
            this.lblChapa4LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa4LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa4LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa4LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa4LEAR.Location = new System.Drawing.Point(329, 19);
            this.lblChapa4LEAR.Name = "lblChapa4LEAR";
            this.lblChapa4LEAR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa4LEAR.TabIndex = 65;
            this.lblChapa4LEAR.Text = "4";
            this.lblChapa4LEAR.Click += new System.EventHandler(this.lblChapa4LEAR_Click);
            // 
            // lblChapa3LEAR
            // 
            this.lblChapa3LEAR.AutoSize = true;
            this.lblChapa3LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa3LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa3LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa3LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa3LEAR.Location = new System.Drawing.Point(229, 19);
            this.lblChapa3LEAR.Name = "lblChapa3LEAR";
            this.lblChapa3LEAR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa3LEAR.TabIndex = 65;
            this.lblChapa3LEAR.Text = "3";
            this.lblChapa3LEAR.Click += new System.EventHandler(this.lblChapa3LEAR_Click);
            // 
            // lblChapa2LEAR
            // 
            this.lblChapa2LEAR.AutoSize = true;
            this.lblChapa2LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa2LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa2LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa2LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa2LEAR.Location = new System.Drawing.Point(134, 19);
            this.lblChapa2LEAR.Name = "lblChapa2LEAR";
            this.lblChapa2LEAR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa2LEAR.TabIndex = 65;
            this.lblChapa2LEAR.Text = "2";
            this.lblChapa2LEAR.Click += new System.EventHandler(this.lblChapa2LEAR_Click);
            // 
            // lblChapa1LEAR
            // 
            this.lblChapa1LEAR.AutoSize = true;
            this.lblChapa1LEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblChapa1LEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblChapa1LEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.lblChapa1LEAR.ForeColor = System.Drawing.Color.Black;
            this.lblChapa1LEAR.Location = new System.Drawing.Point(43, 27);
            this.lblChapa1LEAR.Name = "lblChapa1LEAR";
            this.lblChapa1LEAR.Size = new System.Drawing.Size(24, 25);
            this.lblChapa1LEAR.TabIndex = 65;
            this.lblChapa1LEAR.Text = "1";
            this.lblChapa1LEAR.Click += new System.EventHandler(this.lblChapa1LEAR_Click);
            // 
            // pnlDianteira
            // 
            this.pnlDianteira.BackColor = System.Drawing.Color.Transparent;
            this.pnlDianteira.Controls.Add(this.lblPonteiraDDAR);
            this.pnlDianteira.Controls.Add(this.lblParachoqueDAR);
            this.pnlDianteira.Controls.Add(this.lblPonteiraDEAR);
            this.pnlDianteira.Controls.Add(this.lblGradeAR);
            this.pnlDianteira.Location = new System.Drawing.Point(801, 152);
            this.pnlDianteira.Name = "pnlDianteira";
            this.pnlDianteira.Size = new System.Drawing.Size(200, 100);
            this.pnlDianteira.TabIndex = 65;
            // 
            // lblPonteiraDDAR
            // 
            this.lblPonteiraDDAR.AutoSize = true;
            this.lblPonteiraDDAR.BackColor = System.Drawing.Color.Transparent;
            this.lblPonteiraDDAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPonteiraDDAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPonteiraDDAR.Location = new System.Drawing.Point(157, 52);
            this.lblPonteiraDDAR.Name = "lblPonteiraDDAR";
            this.lblPonteiraDDAR.Size = new System.Drawing.Size(19, 20);
            this.lblPonteiraDDAR.TabIndex = 66;
            this.lblPonteiraDDAR.Text = "4";
            this.lblPonteiraDDAR.Click += new System.EventHandler(this.lblPonteiraDDAR_Click);
            // 
            // lblParachoqueDAR
            // 
            this.lblParachoqueDAR.AutoSize = true;
            this.lblParachoqueDAR.BackColor = System.Drawing.Color.Transparent;
            this.lblParachoqueDAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblParachoqueDAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParachoqueDAR.Location = new System.Drawing.Point(84, 46);
            this.lblParachoqueDAR.Name = "lblParachoqueDAR";
            this.lblParachoqueDAR.Size = new System.Drawing.Size(19, 20);
            this.lblParachoqueDAR.TabIndex = 66;
            this.lblParachoqueDAR.Text = "3";
            this.lblParachoqueDAR.Click += new System.EventHandler(this.lblParachoqueDAR_Click);
            // 
            // lblPonteiraDEAR
            // 
            this.lblPonteiraDEAR.AutoSize = true;
            this.lblPonteiraDEAR.BackColor = System.Drawing.Color.Transparent;
            this.lblPonteiraDEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPonteiraDEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPonteiraDEAR.Location = new System.Drawing.Point(19, 52);
            this.lblPonteiraDEAR.Name = "lblPonteiraDEAR";
            this.lblPonteiraDEAR.Size = new System.Drawing.Size(19, 20);
            this.lblPonteiraDEAR.TabIndex = 66;
            this.lblPonteiraDEAR.Text = "2";
            this.lblPonteiraDEAR.Click += new System.EventHandler(this.lblPonteiraDEAR_Click);
            // 
            // lblGradeAR
            // 
            this.lblGradeAR.AutoSize = true;
            this.lblGradeAR.BackColor = System.Drawing.Color.Transparent;
            this.lblGradeAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblGradeAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGradeAR.Location = new System.Drawing.Point(84, 21);
            this.lblGradeAR.Name = "lblGradeAR";
            this.lblGradeAR.Size = new System.Drawing.Size(19, 20);
            this.lblGradeAR.TabIndex = 66;
            this.lblGradeAR.Text = "1";
            this.lblGradeAR.Click += new System.EventHandler(this.lblGradeAR_Click);
            // 
            // pnlTraseira
            // 
            this.pnlTraseira.BackColor = System.Drawing.Color.Transparent;
            this.pnlTraseira.Controls.Add(this.lblColunaTD2);
            this.pnlTraseira.Controls.Add(this.lblPonteiraTD);
            this.pnlTraseira.Controls.Add(this.lblParachoqueT);
            this.pnlTraseira.Controls.Add(this.lblPonteiraTE);
            this.pnlTraseira.Controls.Add(this.lblColunaTE1);
            this.pnlTraseira.Controls.Add(this.lblTraseiraM);
            this.pnlTraseira.Location = new System.Drawing.Point(800, 258);
            this.pnlTraseira.Name = "pnlTraseira";
            this.pnlTraseira.Size = new System.Drawing.Size(200, 291);
            this.pnlTraseira.TabIndex = 66;
            // 
            // lblColunaTD2
            // 
            this.lblColunaTD2.AutoSize = true;
            this.lblColunaTD2.BackColor = System.Drawing.Color.Transparent;
            this.lblColunaTD2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblColunaTD2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColunaTD2.Location = new System.Drawing.Point(162, 103);
            this.lblColunaTD2.Name = "lblColunaTD2";
            this.lblColunaTD2.Size = new System.Drawing.Size(19, 20);
            this.lblColunaTD2.TabIndex = 66;
            this.lblColunaTD2.Text = "3";
            this.lblColunaTD2.Click += new System.EventHandler(this.lblColunaTD2_Click);
            // 
            // lblPonteiraTD
            // 
            this.lblPonteiraTD.AutoSize = true;
            this.lblPonteiraTD.BackColor = System.Drawing.Color.Transparent;
            this.lblPonteiraTD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPonteiraTD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPonteiraTD.Location = new System.Drawing.Point(162, 191);
            this.lblPonteiraTD.Name = "lblPonteiraTD";
            this.lblPonteiraTD.Size = new System.Drawing.Size(19, 20);
            this.lblPonteiraTD.TabIndex = 66;
            this.lblPonteiraTD.Text = "6";
            this.lblPonteiraTD.Click += new System.EventHandler(this.lblPonteiraTD_Click);
            // 
            // lblParachoqueT
            // 
            this.lblParachoqueT.AutoSize = true;
            this.lblParachoqueT.BackColor = System.Drawing.Color.Transparent;
            this.lblParachoqueT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblParachoqueT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParachoqueT.Location = new System.Drawing.Point(85, 201);
            this.lblParachoqueT.Name = "lblParachoqueT";
            this.lblParachoqueT.Size = new System.Drawing.Size(19, 20);
            this.lblParachoqueT.TabIndex = 66;
            this.lblParachoqueT.Text = "5";
            this.lblParachoqueT.Click += new System.EventHandler(this.lblParachoqueT_Click);
            // 
            // lblPonteiraTE
            // 
            this.lblPonteiraTE.AutoSize = true;
            this.lblPonteiraTE.BackColor = System.Drawing.Color.Transparent;
            this.lblPonteiraTE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblPonteiraTE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPonteiraTE.Location = new System.Drawing.Point(8, 191);
            this.lblPonteiraTE.Name = "lblPonteiraTE";
            this.lblPonteiraTE.Size = new System.Drawing.Size(19, 20);
            this.lblPonteiraTE.TabIndex = 66;
            this.lblPonteiraTE.Text = "4";
            this.lblPonteiraTE.Click += new System.EventHandler(this.lblPonteiraTE_Click);
            // 
            // lblColunaTE1
            // 
            this.lblColunaTE1.AutoSize = true;
            this.lblColunaTE1.BackColor = System.Drawing.Color.Transparent;
            this.lblColunaTE1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblColunaTE1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColunaTE1.Location = new System.Drawing.Point(8, 103);
            this.lblColunaTE1.Name = "lblColunaTE1";
            this.lblColunaTE1.Size = new System.Drawing.Size(19, 20);
            this.lblColunaTE1.TabIndex = 66;
            this.lblColunaTE1.Text = "1";
            this.lblColunaTE1.Click += new System.EventHandler(this.lblColunaTE1_Click);
            // 
            // lblTraseiraM
            // 
            this.lblTraseiraM.AutoSize = true;
            this.lblTraseiraM.BackColor = System.Drawing.Color.Transparent;
            this.lblTraseiraM.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblTraseiraM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTraseiraM.Location = new System.Drawing.Point(85, 131);
            this.lblTraseiraM.Name = "lblTraseiraM";
            this.lblTraseiraM.Size = new System.Drawing.Size(19, 20);
            this.lblTraseiraM.TabIndex = 66;
            this.lblTraseiraM.Text = "2";
            this.lblTraseiraM.Click += new System.EventHandler(this.lblTraseiraM_Click);
            // 
            // btnNovaAvaria
            // 
            this.btnNovaAvaria.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnNovaAvaria.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovaAvaria.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovaAvaria.Location = new System.Drawing.Point(7, 679);
            this.btnNovaAvaria.Name = "btnNovaAvaria";
            this.btnNovaAvaria.Size = new System.Drawing.Size(105, 30);
            this.btnNovaAvaria.TabIndex = 67;
            this.btnNovaAvaria.Text = "Nova Avaria";
            this.btnNovaAvaria.UseVisualStyleBackColor = true;
            this.btnNovaAvaria.Click += new System.EventHandler(this.btnNovaAvaria_Click);
            // 
            // manutencao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Empresa2.Properties.Resources._1519Lourdes;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1002, 767);
            this.Controls.Add(this.btnNovaAvaria);
            this.Controls.Add(this.pnlTraseira);
            this.Controls.Add(this.pnlDianteira);
            this.Controls.Add(this.pnlLEAR);
            this.Controls.Add(this.pnlLDAR);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.combNordem);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.picAjudaAvaria);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.txtAvariaA);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.lblAvaria);
            this.Controls.Add(this.lblNordem);
            this.Controls.Add(this.txtModelo);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "manutencao";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Manutenção";
            this.Load += new System.EventHandler(this.Anotador_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picAjudaAvaria)).EndInit();
            this.pnlLDAR.ResumeLayout(false);
            this.pnlLDAR.PerformLayout();
            this.pnlLEAR.ResumeLayout(false);
            this.pnlLEAR.PerformLayout();
            this.pnlDianteira.ResumeLayout(false);
            this.pnlDianteira.PerformLayout();
            this.pnlTraseira.ResumeLayout(false);
            this.pnlTraseira.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.TextBox txtModelo;
        private System.Windows.Forms.Label lblNordem;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.TextBox txtAvariaA;
        private System.Windows.Forms.Label lblAvaria;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.PictureBox picAjudaAvaria;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox combNordem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnlLDAR;
        private System.Windows.Forms.Label lblChapa1AR;
        private System.Windows.Forms.Label lblChapa6AR;
        private System.Windows.Forms.Label lblChapa5AR;
        private System.Windows.Forms.Label lblChapa4AR;
        private System.Windows.Forms.Label lblChapa3AR;
        private System.Windows.Forms.Label lblChapa2AR;
        private System.Windows.Forms.Label lblChapa17AR;
        private System.Windows.Forms.Label lblChapa16AR;
        private System.Windows.Forms.Label lblChapa15AR;
        private System.Windows.Forms.Label lblChapa14AR;
        private System.Windows.Forms.Label lblChapa13AR;
        private System.Windows.Forms.Label lblChapa12AR;
        private System.Windows.Forms.Label lblChapa11AR;
        private System.Windows.Forms.Label lblChapa10AR;
        private System.Windows.Forms.Label lblChapa9AR;
        private System.Windows.Forms.Label lblChapa8AR;
        private System.Windows.Forms.Label lblChapa7AR;
        private System.Windows.Forms.Panel pnlLEAR;
        private System.Windows.Forms.Label lblColunaTEAR;
        private System.Windows.Forms.Label lblChapa18LEAR;
        private System.Windows.Forms.Label lblChapa17LEAR;
        private System.Windows.Forms.Label lblChapa16LEAR;
        private System.Windows.Forms.Label lblChapa15LEAR;
        private System.Windows.Forms.Label lblChapa14LEAR;
        private System.Windows.Forms.Label lblChapa13LEAR;
        private System.Windows.Forms.Label lblChapa12LEAR;
        private System.Windows.Forms.Label lblChapa11LEAR;
        private System.Windows.Forms.Label lblChapa10LEAR;
        private System.Windows.Forms.Label lblChapa9LEAR;
        private System.Windows.Forms.Label lblChapa8LEAR;
        private System.Windows.Forms.Label lblChapa7LEAR;
        private System.Windows.Forms.Label lblChapa6LEAR;
        private System.Windows.Forms.Label lblChapa5LEAR;
        private System.Windows.Forms.Label lblChapa4LEAR;
        private System.Windows.Forms.Label lblChapa3LEAR;
        private System.Windows.Forms.Label lblChapa2LEAR;
        private System.Windows.Forms.Label lblChapa1LEAR;
        private System.Windows.Forms.Panel pnlDianteira;
        private System.Windows.Forms.Label lblPonteiraDDAR;
        private System.Windows.Forms.Label lblParachoqueDAR;
        private System.Windows.Forms.Label lblPonteiraDEAR;
        private System.Windows.Forms.Label lblGradeAR;
        private System.Windows.Forms.Panel pnlTraseira;
        private System.Windows.Forms.Label lblColunaTD2;
        private System.Windows.Forms.Label lblPonteiraTD;
        private System.Windows.Forms.Label lblParachoqueT;
        private System.Windows.Forms.Label lblPonteiraTE;
        private System.Windows.Forms.Label lblColunaTE1;
        private System.Windows.Forms.Label lblTraseiraM;
        private System.Windows.Forms.Button btnNovaAvaria;
        protected internal System.Windows.Forms.Label lblColunaTDAR;
    }
}