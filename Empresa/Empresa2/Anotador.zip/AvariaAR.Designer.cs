﻿namespace Empresa2
{
    partial class AvariaAR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AvariaAR));
            this.check1LD = new System.Windows.Forms.CheckBox();
            this.check2LD = new System.Windows.Forms.CheckBox();
            this.pnlCheckLD = new System.Windows.Forms.Panel();
            this.check0LD = new System.Windows.Forms.CheckBox();
            this.check17LD = new System.Windows.Forms.CheckBox();
            this.check16LD = new System.Windows.Forms.CheckBox();
            this.check15LD = new System.Windows.Forms.CheckBox();
            this.check14LD = new System.Windows.Forms.CheckBox();
            this.check13LD = new System.Windows.Forms.CheckBox();
            this.check12LD = new System.Windows.Forms.CheckBox();
            this.check11LD = new System.Windows.Forms.CheckBox();
            this.check10LD = new System.Windows.Forms.CheckBox();
            this.check9LD = new System.Windows.Forms.CheckBox();
            this.check8LD = new System.Windows.Forms.CheckBox();
            this.check7LD = new System.Windows.Forms.CheckBox();
            this.check6LD = new System.Windows.Forms.CheckBox();
            this.check5LD = new System.Windows.Forms.CheckBox();
            this.check4LD = new System.Windows.Forms.CheckBox();
            this.check3LD = new System.Windows.Forms.CheckBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnNovaAvaria = new System.Windows.Forms.Button();
            this.rbLD = new System.Windows.Forms.RadioButton();
            this.rbLE = new System.Windows.Forms.RadioButton();
            this.rbDianteira = new System.Windows.Forms.RadioButton();
            this.checkCP = new System.Windows.Forms.CheckBox();
            this.checkP = new System.Windows.Forms.CheckBox();
            this.rbTraseira = new System.Windows.Forms.RadioButton();
            this.pnlCheckLE = new System.Windows.Forms.Panel();
            this.check19LE = new System.Windows.Forms.CheckBox();
            this.check18LE = new System.Windows.Forms.CheckBox();
            this.check17LE = new System.Windows.Forms.CheckBox();
            this.check16LE = new System.Windows.Forms.CheckBox();
            this.check15LE = new System.Windows.Forms.CheckBox();
            this.check14LE = new System.Windows.Forms.CheckBox();
            this.check13LE = new System.Windows.Forms.CheckBox();
            this.check12LE = new System.Windows.Forms.CheckBox();
            this.check11LE = new System.Windows.Forms.CheckBox();
            this.check10LE = new System.Windows.Forms.CheckBox();
            this.check9LE = new System.Windows.Forms.CheckBox();
            this.check8LE = new System.Windows.Forms.CheckBox();
            this.check7LE = new System.Windows.Forms.CheckBox();
            this.check6LE = new System.Windows.Forms.CheckBox();
            this.check5LE = new System.Windows.Forms.CheckBox();
            this.check4LE = new System.Windows.Forms.CheckBox();
            this.check3LE = new System.Windows.Forms.CheckBox();
            this.check2LE = new System.Windows.Forms.CheckBox();
            this.check1LE = new System.Windows.Forms.CheckBox();
            this.pnlCheckTraseira = new System.Windows.Forms.Panel();
            this.check6Tr = new System.Windows.Forms.CheckBox();
            this.check3Tr = new System.Windows.Forms.CheckBox();
            this.check5Tr = new System.Windows.Forms.CheckBox();
            this.check2Tr = new System.Windows.Forms.CheckBox();
            this.check4Tr = new System.Windows.Forms.CheckBox();
            this.check1Tr = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlCheckFrente = new System.Windows.Forms.Panel();
            this.check4Frente = new System.Windows.Forms.CheckBox();
            this.check3Frente = new System.Windows.Forms.CheckBox();
            this.check2Frente = new System.Windows.Forms.CheckBox();
            this.check1Frente = new System.Windows.Forms.CheckBox();
            this.pnlFechar = new System.Windows.Forms.Panel();
            this.lblFechar = new System.Windows.Forms.Label();
            this.btnCalcular1722 = new System.Windows.Forms.Button();
            this.btnCalcularAR = new System.Windows.Forms.Button();
            this.txtModelo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.combNordem = new System.Windows.Forms.ComboBox();
            this.btnPesquisarAvaria = new System.Windows.Forms.Button();
            this.pnlCheckLD.SuspendLayout();
            this.pnlCheckLE.SuspendLayout();
            this.pnlCheckTraseira.SuspendLayout();
            this.pnlCheckFrente.SuspendLayout();
            this.pnlFechar.SuspendLayout();
            this.SuspendLayout();
            // 
            // check1LD
            // 
            this.check1LD.AutoSize = true;
            this.check1LD.BackColor = System.Drawing.Color.Transparent;
            this.check1LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check1LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check1LD.ForeColor = System.Drawing.Color.White;
            this.check1LD.Location = new System.Drawing.Point(47, 3);
            this.check1LD.Name = "check1LD";
            this.check1LD.Size = new System.Drawing.Size(37, 24);
            this.check1LD.TabIndex = 1;
            this.check1LD.Text = "1";
            this.check1LD.UseVisualStyleBackColor = false;
            // 
            // check2LD
            // 
            this.check2LD.AutoSize = true;
            this.check2LD.BackColor = System.Drawing.Color.Transparent;
            this.check2LD.FlatAppearance.BorderSize = 0;
            this.check2LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check2LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check2LD.ForeColor = System.Drawing.Color.White;
            this.check2LD.Location = new System.Drawing.Point(91, 3);
            this.check2LD.Name = "check2LD";
            this.check2LD.Size = new System.Drawing.Size(37, 24);
            this.check2LD.TabIndex = 3;
            this.check2LD.Text = "2";
            this.check2LD.UseVisualStyleBackColor = false;
            // 
            // pnlCheckLD
            // 
            this.pnlCheckLD.BackColor = System.Drawing.Color.Transparent;
            this.pnlCheckLD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCheckLD.Controls.Add(this.check0LD);
            this.pnlCheckLD.Controls.Add(this.check17LD);
            this.pnlCheckLD.Controls.Add(this.check16LD);
            this.pnlCheckLD.Controls.Add(this.check15LD);
            this.pnlCheckLD.Controls.Add(this.check14LD);
            this.pnlCheckLD.Controls.Add(this.check13LD);
            this.pnlCheckLD.Controls.Add(this.check12LD);
            this.pnlCheckLD.Controls.Add(this.check11LD);
            this.pnlCheckLD.Controls.Add(this.check10LD);
            this.pnlCheckLD.Controls.Add(this.check9LD);
            this.pnlCheckLD.Controls.Add(this.check8LD);
            this.pnlCheckLD.Controls.Add(this.check7LD);
            this.pnlCheckLD.Controls.Add(this.check6LD);
            this.pnlCheckLD.Controls.Add(this.check5LD);
            this.pnlCheckLD.Controls.Add(this.check4LD);
            this.pnlCheckLD.Controls.Add(this.check3LD);
            this.pnlCheckLD.Controls.Add(this.check2LD);
            this.pnlCheckLD.Controls.Add(this.check1LD);
            this.pnlCheckLD.Location = new System.Drawing.Point(358, 602);
            this.pnlCheckLD.Name = "pnlCheckLD";
            this.pnlCheckLD.Size = new System.Drawing.Size(324, 115);
            this.pnlCheckLD.TabIndex = 5;
            this.pnlCheckLD.Visible = false;
            // 
            // check0LD
            // 
            this.check0LD.AutoSize = true;
            this.check0LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check0LD.ForeColor = System.Drawing.Color.White;
            this.check0LD.Location = new System.Drawing.Point(3, 3);
            this.check0LD.Name = "check0LD";
            this.check0LD.Size = new System.Drawing.Size(37, 24);
            this.check0LD.TabIndex = 19;
            this.check0LD.Text = "0";
            this.check0LD.UseVisualStyleBackColor = true;
            // 
            // check17LD
            // 
            this.check17LD.AutoSize = true;
            this.check17LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check17LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check17LD.ForeColor = System.Drawing.Color.White;
            this.check17LD.Location = new System.Drawing.Point(220, 68);
            this.check17LD.Name = "check17LD";
            this.check17LD.Size = new System.Drawing.Size(46, 24);
            this.check17LD.TabIndex = 18;
            this.check17LD.Text = "17";
            this.check17LD.UseVisualStyleBackColor = true;
            // 
            // check16LD
            // 
            this.check16LD.AutoSize = true;
            this.check16LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check16LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check16LD.ForeColor = System.Drawing.Color.White;
            this.check16LD.Location = new System.Drawing.Point(177, 68);
            this.check16LD.Name = "check16LD";
            this.check16LD.Size = new System.Drawing.Size(46, 24);
            this.check16LD.TabIndex = 17;
            this.check16LD.Text = "16";
            this.check16LD.UseVisualStyleBackColor = true;
            // 
            // check15LD
            // 
            this.check15LD.AutoSize = true;
            this.check15LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check15LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check15LD.ForeColor = System.Drawing.Color.White;
            this.check15LD.Location = new System.Drawing.Point(134, 68);
            this.check15LD.Name = "check15LD";
            this.check15LD.Size = new System.Drawing.Size(46, 24);
            this.check15LD.TabIndex = 16;
            this.check15LD.Text = "15";
            this.check15LD.UseVisualStyleBackColor = true;
            // 
            // check14LD
            // 
            this.check14LD.AutoSize = true;
            this.check14LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check14LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check14LD.ForeColor = System.Drawing.Color.White;
            this.check14LD.Location = new System.Drawing.Point(91, 68);
            this.check14LD.Name = "check14LD";
            this.check14LD.Size = new System.Drawing.Size(46, 24);
            this.check14LD.TabIndex = 15;
            this.check14LD.Text = "14";
            this.check14LD.UseVisualStyleBackColor = true;
            // 
            // check13LD
            // 
            this.check13LD.AutoSize = true;
            this.check13LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check13LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check13LD.ForeColor = System.Drawing.Color.White;
            this.check13LD.Location = new System.Drawing.Point(47, 68);
            this.check13LD.Name = "check13LD";
            this.check13LD.Size = new System.Drawing.Size(46, 24);
            this.check13LD.TabIndex = 14;
            this.check13LD.Text = "13";
            this.check13LD.UseVisualStyleBackColor = true;
            // 
            // check12LD
            // 
            this.check12LD.AutoSize = true;
            this.check12LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check12LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check12LD.ForeColor = System.Drawing.Color.White;
            this.check12LD.Location = new System.Drawing.Point(3, 68);
            this.check12LD.Name = "check12LD";
            this.check12LD.Size = new System.Drawing.Size(46, 24);
            this.check12LD.TabIndex = 13;
            this.check12LD.Text = "12";
            this.check12LD.UseVisualStyleBackColor = true;
            // 
            // check11LD
            // 
            this.check11LD.AutoSize = true;
            this.check11LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check11LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check11LD.ForeColor = System.Drawing.Color.White;
            this.check11LD.Location = new System.Drawing.Point(220, 38);
            this.check11LD.Name = "check11LD";
            this.check11LD.Size = new System.Drawing.Size(46, 24);
            this.check11LD.TabIndex = 12;
            this.check11LD.Text = "11";
            this.check11LD.UseVisualStyleBackColor = true;
            // 
            // check10LD
            // 
            this.check10LD.AutoSize = true;
            this.check10LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check10LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check10LD.ForeColor = System.Drawing.Color.White;
            this.check10LD.Location = new System.Drawing.Point(177, 38);
            this.check10LD.Name = "check10LD";
            this.check10LD.Size = new System.Drawing.Size(46, 24);
            this.check10LD.TabIndex = 11;
            this.check10LD.Text = "10";
            this.check10LD.UseVisualStyleBackColor = true;
            // 
            // check9LD
            // 
            this.check9LD.AutoSize = true;
            this.check9LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check9LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check9LD.ForeColor = System.Drawing.Color.White;
            this.check9LD.Location = new System.Drawing.Point(134, 38);
            this.check9LD.Name = "check9LD";
            this.check9LD.Size = new System.Drawing.Size(37, 24);
            this.check9LD.TabIndex = 10;
            this.check9LD.Text = "9";
            this.check9LD.UseVisualStyleBackColor = true;
            // 
            // check8LD
            // 
            this.check8LD.AutoSize = true;
            this.check8LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check8LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check8LD.ForeColor = System.Drawing.Color.White;
            this.check8LD.Location = new System.Drawing.Point(91, 38);
            this.check8LD.Name = "check8LD";
            this.check8LD.Size = new System.Drawing.Size(37, 24);
            this.check8LD.TabIndex = 9;
            this.check8LD.Text = "8";
            this.check8LD.UseVisualStyleBackColor = true;
            // 
            // check7LD
            // 
            this.check7LD.AutoSize = true;
            this.check7LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check7LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check7LD.ForeColor = System.Drawing.Color.White;
            this.check7LD.Location = new System.Drawing.Point(47, 38);
            this.check7LD.Name = "check7LD";
            this.check7LD.Size = new System.Drawing.Size(37, 24);
            this.check7LD.TabIndex = 8;
            this.check7LD.Text = "7";
            this.check7LD.UseVisualStyleBackColor = true;
            // 
            // check6LD
            // 
            this.check6LD.AutoSize = true;
            this.check6LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check6LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check6LD.ForeColor = System.Drawing.Color.White;
            this.check6LD.Location = new System.Drawing.Point(3, 38);
            this.check6LD.Name = "check6LD";
            this.check6LD.Size = new System.Drawing.Size(37, 24);
            this.check6LD.TabIndex = 7;
            this.check6LD.Text = "6";
            this.check6LD.UseVisualStyleBackColor = true;
            // 
            // check5LD
            // 
            this.check5LD.AutoSize = true;
            this.check5LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check5LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check5LD.ForeColor = System.Drawing.Color.White;
            this.check5LD.Location = new System.Drawing.Point(220, 3);
            this.check5LD.Name = "check5LD";
            this.check5LD.Size = new System.Drawing.Size(37, 24);
            this.check5LD.TabIndex = 6;
            this.check5LD.Text = "5";
            this.check5LD.UseVisualStyleBackColor = true;
            // 
            // check4LD
            // 
            this.check4LD.AutoSize = true;
            this.check4LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check4LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check4LD.ForeColor = System.Drawing.Color.White;
            this.check4LD.Location = new System.Drawing.Point(177, 3);
            this.check4LD.Name = "check4LD";
            this.check4LD.Size = new System.Drawing.Size(37, 24);
            this.check4LD.TabIndex = 5;
            this.check4LD.Text = "4";
            this.check4LD.UseVisualStyleBackColor = true;
            // 
            // check3LD
            // 
            this.check3LD.AutoSize = true;
            this.check3LD.FlatAppearance.CheckedBackColor = System.Drawing.Color.Gray;
            this.check3LD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check3LD.ForeColor = System.Drawing.Color.White;
            this.check3LD.Location = new System.Drawing.Point(134, 3);
            this.check3LD.Name = "check3LD";
            this.check3LD.Size = new System.Drawing.Size(37, 24);
            this.check3LD.TabIndex = 4;
            this.check3LD.Text = "3";
            this.check3LD.UseVisualStyleBackColor = true;
            // 
            // btnCalcular
            // 
            this.btnCalcular.FlatAppearance.BorderSize = 0;
            this.btnCalcular.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(7, 576);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(112, 33);
            this.btnCalcular.TabIndex = 2;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnNovaAvaria
            // 
            this.btnNovaAvaria.FlatAppearance.BorderSize = 0;
            this.btnNovaAvaria.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovaAvaria.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovaAvaria.Location = new System.Drawing.Point(7, 618);
            this.btnNovaAvaria.Name = "btnNovaAvaria";
            this.btnNovaAvaria.Size = new System.Drawing.Size(112, 33);
            this.btnNovaAvaria.TabIndex = 1;
            this.btnNovaAvaria.Text = "Nova Avaria";
            this.btnNovaAvaria.UseVisualStyleBackColor = true;
            this.btnNovaAvaria.Click += new System.EventHandler(this.button1_Click);
            // 
            // rbLD
            // 
            this.rbLD.AutoSize = true;
            this.rbLD.BackColor = System.Drawing.Color.Transparent;
            this.rbLD.Checked = true;
            this.rbLD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbLD.ForeColor = System.Drawing.Color.White;
            this.rbLD.Location = new System.Drawing.Point(754, 673);
            this.rbLD.Name = "rbLD";
            this.rbLD.Size = new System.Drawing.Size(125, 24);
            this.rbLD.TabIndex = 8;
            this.rbLD.TabStop = true;
            this.rbLD.Text = "Lado Direito";
            this.rbLD.UseVisualStyleBackColor = false;
            this.rbLD.CheckedChanged += new System.EventHandler(this.btn2LD_CheckedChanged);
            // 
            // rbLE
            // 
            this.rbLE.AutoSize = true;
            this.rbLE.BackColor = System.Drawing.Color.Transparent;
            this.rbLE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbLE.ForeColor = System.Drawing.Color.White;
            this.rbLE.Location = new System.Drawing.Point(754, 643);
            this.rbLE.Name = "rbLE";
            this.rbLE.Size = new System.Drawing.Size(149, 24);
            this.rbLE.TabIndex = 7;
            this.rbLE.Text = "Lado Esquerdo";
            this.rbLE.UseVisualStyleBackColor = false;
            this.rbLE.CheckedChanged += new System.EventHandler(this.rbLE_CheckedChanged);
            // 
            // rbDianteira
            // 
            this.rbDianteira.AutoSize = true;
            this.rbDianteira.BackColor = System.Drawing.Color.Transparent;
            this.rbDianteira.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbDianteira.ForeColor = System.Drawing.Color.White;
            this.rbDianteira.Location = new System.Drawing.Point(754, 611);
            this.rbDianteira.Name = "rbDianteira";
            this.rbDianteira.Size = new System.Drawing.Size(100, 24);
            this.rbDianteira.TabIndex = 6;
            this.rbDianteira.Text = "Dianteira";
            this.rbDianteira.UseVisualStyleBackColor = false;
            this.rbDianteira.CheckedChanged += new System.EventHandler(this.rbDianteira_CheckedChanged);
            // 
            // checkCP
            // 
            this.checkCP.AutoSize = true;
            this.checkCP.BackColor = System.Drawing.Color.Transparent;
            this.checkCP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkCP.ForeColor = System.Drawing.Color.White;
            this.checkCP.Location = new System.Drawing.Point(754, 524);
            this.checkCP.Name = "checkCP";
            this.checkCP.Size = new System.Drawing.Size(183, 24);
            this.checkCP.TabIndex = 3;
            this.checkCP.Text = "Carroceria / Pintura";
            this.checkCP.UseVisualStyleBackColor = false;
            this.checkCP.CheckedChanged += new System.EventHandler(this.checkCP_CheckedChanged);
            // 
            // checkP
            // 
            this.checkP.AutoSize = true;
            this.checkP.BackColor = System.Drawing.Color.Transparent;
            this.checkP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkP.ForeColor = System.Drawing.Color.White;
            this.checkP.Location = new System.Drawing.Point(754, 549);
            this.checkP.Name = "checkP";
            this.checkP.Size = new System.Drawing.Size(85, 24);
            this.checkP.TabIndex = 4;
            this.checkP.Text = "Pintura";
            this.checkP.UseVisualStyleBackColor = false;
            this.checkP.CheckedChanged += new System.EventHandler(this.checkP_CheckedChanged);
            // 
            // rbTraseira
            // 
            this.rbTraseira.AutoSize = true;
            this.rbTraseira.BackColor = System.Drawing.Color.Transparent;
            this.rbTraseira.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbTraseira.ForeColor = System.Drawing.Color.White;
            this.rbTraseira.Location = new System.Drawing.Point(754, 581);
            this.rbTraseira.Name = "rbTraseira";
            this.rbTraseira.Size = new System.Drawing.Size(92, 24);
            this.rbTraseira.TabIndex = 5;
            this.rbTraseira.TabStop = true;
            this.rbTraseira.Text = "Traseira";
            this.rbTraseira.UseVisualStyleBackColor = false;
            this.rbTraseira.CheckedChanged += new System.EventHandler(this.rbTraseira_CheckedChanged);
            // 
            // pnlCheckLE
            // 
            this.pnlCheckLE.BackColor = System.Drawing.Color.Transparent;
            this.pnlCheckLE.Controls.Add(this.check19LE);
            this.pnlCheckLE.Controls.Add(this.check18LE);
            this.pnlCheckLE.Controls.Add(this.check17LE);
            this.pnlCheckLE.Controls.Add(this.check16LE);
            this.pnlCheckLE.Controls.Add(this.check15LE);
            this.pnlCheckLE.Controls.Add(this.check14LE);
            this.pnlCheckLE.Controls.Add(this.check13LE);
            this.pnlCheckLE.Controls.Add(this.check12LE);
            this.pnlCheckLE.Controls.Add(this.check11LE);
            this.pnlCheckLE.Controls.Add(this.check10LE);
            this.pnlCheckLE.Controls.Add(this.check9LE);
            this.pnlCheckLE.Controls.Add(this.check8LE);
            this.pnlCheckLE.Controls.Add(this.check7LE);
            this.pnlCheckLE.Controls.Add(this.check6LE);
            this.pnlCheckLE.Controls.Add(this.check5LE);
            this.pnlCheckLE.Controls.Add(this.check4LE);
            this.pnlCheckLE.Controls.Add(this.check3LE);
            this.pnlCheckLE.Controls.Add(this.check2LE);
            this.pnlCheckLE.Controls.Add(this.check1LE);
            this.pnlCheckLE.ForeColor = System.Drawing.Color.Black;
            this.pnlCheckLE.Location = new System.Drawing.Point(367, 594);
            this.pnlCheckLE.Name = "pnlCheckLE";
            this.pnlCheckLE.Size = new System.Drawing.Size(324, 126);
            this.pnlCheckLE.TabIndex = 19;
            this.pnlCheckLE.Visible = false;
            // 
            // check19LE
            // 
            this.check19LE.AutoSize = true;
            this.check19LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.check19LE.ForeColor = System.Drawing.Color.White;
            this.check19LE.Location = new System.Drawing.Point(4, 97);
            this.check19LE.Name = "check19LE";
            this.check19LE.Size = new System.Drawing.Size(46, 24);
            this.check19LE.TabIndex = 18;
            this.check19LE.Text = "19";
            this.check19LE.UseVisualStyleBackColor = true;
            // 
            // check18LE
            // 
            this.check18LE.AutoSize = true;
            this.check18LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check18LE.ForeColor = System.Drawing.Color.White;
            this.check18LE.Location = new System.Drawing.Point(252, 66);
            this.check18LE.Name = "check18LE";
            this.check18LE.Size = new System.Drawing.Size(46, 24);
            this.check18LE.TabIndex = 17;
            this.check18LE.Text = "18";
            this.check18LE.UseVisualStyleBackColor = true;
            // 
            // check17LE
            // 
            this.check17LE.AutoSize = true;
            this.check17LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check17LE.ForeColor = System.Drawing.Color.White;
            this.check17LE.Location = new System.Drawing.Point(200, 66);
            this.check17LE.Name = "check17LE";
            this.check17LE.Size = new System.Drawing.Size(46, 24);
            this.check17LE.TabIndex = 16;
            this.check17LE.Text = "17";
            this.check17LE.UseVisualStyleBackColor = true;
            // 
            // check16LE
            // 
            this.check16LE.AutoSize = true;
            this.check16LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check16LE.ForeColor = System.Drawing.Color.White;
            this.check16LE.Location = new System.Drawing.Point(148, 66);
            this.check16LE.Name = "check16LE";
            this.check16LE.Size = new System.Drawing.Size(46, 24);
            this.check16LE.TabIndex = 15;
            this.check16LE.Text = "16";
            this.check16LE.UseVisualStyleBackColor = true;
            // 
            // check15LE
            // 
            this.check15LE.AutoSize = true;
            this.check15LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check15LE.ForeColor = System.Drawing.Color.White;
            this.check15LE.Location = new System.Drawing.Point(91, 66);
            this.check15LE.Name = "check15LE";
            this.check15LE.Size = new System.Drawing.Size(46, 24);
            this.check15LE.TabIndex = 14;
            this.check15LE.Text = "15";
            this.check15LE.UseVisualStyleBackColor = true;
            // 
            // check14LE
            // 
            this.check14LE.AutoSize = true;
            this.check14LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check14LE.ForeColor = System.Drawing.Color.White;
            this.check14LE.Location = new System.Drawing.Point(47, 66);
            this.check14LE.Name = "check14LE";
            this.check14LE.Size = new System.Drawing.Size(46, 24);
            this.check14LE.TabIndex = 13;
            this.check14LE.Text = "14";
            this.check14LE.UseVisualStyleBackColor = true;
            // 
            // check13LE
            // 
            this.check13LE.AutoSize = true;
            this.check13LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check13LE.ForeColor = System.Drawing.Color.White;
            this.check13LE.Location = new System.Drawing.Point(4, 66);
            this.check13LE.Name = "check13LE";
            this.check13LE.Size = new System.Drawing.Size(46, 24);
            this.check13LE.TabIndex = 12;
            this.check13LE.Text = "13";
            this.check13LE.UseVisualStyleBackColor = true;
            // 
            // check12LE
            // 
            this.check12LE.AutoSize = true;
            this.check12LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check12LE.ForeColor = System.Drawing.Color.White;
            this.check12LE.Location = new System.Drawing.Point(252, 33);
            this.check12LE.Name = "check12LE";
            this.check12LE.Size = new System.Drawing.Size(46, 24);
            this.check12LE.TabIndex = 11;
            this.check12LE.Text = "12";
            this.check12LE.UseVisualStyleBackColor = true;
            // 
            // check11LE
            // 
            this.check11LE.AutoSize = true;
            this.check11LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check11LE.ForeColor = System.Drawing.Color.White;
            this.check11LE.Location = new System.Drawing.Point(200, 33);
            this.check11LE.Name = "check11LE";
            this.check11LE.Size = new System.Drawing.Size(46, 24);
            this.check11LE.TabIndex = 10;
            this.check11LE.Text = "11";
            this.check11LE.UseVisualStyleBackColor = true;
            // 
            // check10LE
            // 
            this.check10LE.AutoSize = true;
            this.check10LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check10LE.ForeColor = System.Drawing.Color.White;
            this.check10LE.Location = new System.Drawing.Point(148, 34);
            this.check10LE.Name = "check10LE";
            this.check10LE.Size = new System.Drawing.Size(46, 24);
            this.check10LE.TabIndex = 9;
            this.check10LE.Text = "10";
            this.check10LE.UseVisualStyleBackColor = true;
            // 
            // check9LE
            // 
            this.check9LE.AutoSize = true;
            this.check9LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check9LE.ForeColor = System.Drawing.Color.White;
            this.check9LE.Location = new System.Drawing.Point(91, 33);
            this.check9LE.Name = "check9LE";
            this.check9LE.Size = new System.Drawing.Size(37, 24);
            this.check9LE.TabIndex = 8;
            this.check9LE.Text = "9";
            this.check9LE.UseVisualStyleBackColor = true;
            // 
            // check8LE
            // 
            this.check8LE.AutoSize = true;
            this.check8LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check8LE.ForeColor = System.Drawing.Color.White;
            this.check8LE.Location = new System.Drawing.Point(47, 33);
            this.check8LE.Name = "check8LE";
            this.check8LE.Size = new System.Drawing.Size(37, 24);
            this.check8LE.TabIndex = 7;
            this.check8LE.Text = "8";
            this.check8LE.UseVisualStyleBackColor = true;
            // 
            // check7LE
            // 
            this.check7LE.AutoSize = true;
            this.check7LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check7LE.ForeColor = System.Drawing.Color.White;
            this.check7LE.Location = new System.Drawing.Point(3, 33);
            this.check7LE.Name = "check7LE";
            this.check7LE.Size = new System.Drawing.Size(37, 24);
            this.check7LE.TabIndex = 6;
            this.check7LE.Text = "7";
            this.check7LE.UseVisualStyleBackColor = true;
            // 
            // check6LE
            // 
            this.check6LE.AutoSize = true;
            this.check6LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check6LE.ForeColor = System.Drawing.Color.White;
            this.check6LE.Location = new System.Drawing.Point(252, 3);
            this.check6LE.Name = "check6LE";
            this.check6LE.Size = new System.Drawing.Size(37, 24);
            this.check6LE.TabIndex = 5;
            this.check6LE.Text = "6";
            this.check6LE.UseVisualStyleBackColor = true;
            // 
            // check5LE
            // 
            this.check5LE.AutoSize = true;
            this.check5LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check5LE.ForeColor = System.Drawing.Color.White;
            this.check5LE.Location = new System.Drawing.Point(200, 3);
            this.check5LE.Name = "check5LE";
            this.check5LE.Size = new System.Drawing.Size(37, 24);
            this.check5LE.TabIndex = 4;
            this.check5LE.Text = "5";
            this.check5LE.UseVisualStyleBackColor = true;
            // 
            // check4LE
            // 
            this.check4LE.AutoSize = true;
            this.check4LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check4LE.ForeColor = System.Drawing.Color.White;
            this.check4LE.Location = new System.Drawing.Point(148, 3);
            this.check4LE.Name = "check4LE";
            this.check4LE.Size = new System.Drawing.Size(37, 24);
            this.check4LE.TabIndex = 3;
            this.check4LE.Text = "4";
            this.check4LE.UseVisualStyleBackColor = true;
            // 
            // check3LE
            // 
            this.check3LE.AutoSize = true;
            this.check3LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check3LE.ForeColor = System.Drawing.Color.White;
            this.check3LE.Location = new System.Drawing.Point(91, 3);
            this.check3LE.Name = "check3LE";
            this.check3LE.Size = new System.Drawing.Size(37, 24);
            this.check3LE.TabIndex = 2;
            this.check3LE.Text = "3";
            this.check3LE.UseVisualStyleBackColor = true;
            // 
            // check2LE
            // 
            this.check2LE.AutoSize = true;
            this.check2LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check2LE.ForeColor = System.Drawing.Color.White;
            this.check2LE.Location = new System.Drawing.Point(51, 3);
            this.check2LE.Name = "check2LE";
            this.check2LE.Size = new System.Drawing.Size(37, 24);
            this.check2LE.TabIndex = 1;
            this.check2LE.Text = "2";
            this.check2LE.UseVisualStyleBackColor = true;
            // 
            // check1LE
            // 
            this.check1LE.AutoSize = true;
            this.check1LE.BackColor = System.Drawing.Color.Transparent;
            this.check1LE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check1LE.ForeColor = System.Drawing.Color.White;
            this.check1LE.Location = new System.Drawing.Point(3, 3);
            this.check1LE.Name = "check1LE";
            this.check1LE.Size = new System.Drawing.Size(37, 24);
            this.check1LE.TabIndex = 0;
            this.check1LE.Text = "1";
            this.check1LE.UseVisualStyleBackColor = false;
            // 
            // pnlCheckTraseira
            // 
            this.pnlCheckTraseira.BackColor = System.Drawing.Color.Transparent;
            this.pnlCheckTraseira.Controls.Add(this.check6Tr);
            this.pnlCheckTraseira.Controls.Add(this.check3Tr);
            this.pnlCheckTraseira.Controls.Add(this.check5Tr);
            this.pnlCheckTraseira.Controls.Add(this.check2Tr);
            this.pnlCheckTraseira.Controls.Add(this.check4Tr);
            this.pnlCheckTraseira.Controls.Add(this.check1Tr);
            this.pnlCheckTraseira.Location = new System.Drawing.Point(354, 613);
            this.pnlCheckTraseira.Name = "pnlCheckTraseira";
            this.pnlCheckTraseira.Size = new System.Drawing.Size(286, 72);
            this.pnlCheckTraseira.TabIndex = 64;
            this.pnlCheckTraseira.Visible = false;
            // 
            // check6Tr
            // 
            this.check6Tr.AutoSize = true;
            this.check6Tr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check6Tr.ForeColor = System.Drawing.Color.White;
            this.check6Tr.Location = new System.Drawing.Point(213, 3);
            this.check6Tr.Name = "check6Tr";
            this.check6Tr.Size = new System.Drawing.Size(38, 24);
            this.check6Tr.TabIndex = 0;
            this.check6Tr.Text = "6";
            this.check6Tr.UseVisualStyleBackColor = true;
            // 
            // check3Tr
            // 
            this.check3Tr.AutoSize = true;
            this.check3Tr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check3Tr.ForeColor = System.Drawing.Color.White;
            this.check3Tr.Location = new System.Drawing.Point(83, 3);
            this.check3Tr.Name = "check3Tr";
            this.check3Tr.Size = new System.Drawing.Size(38, 24);
            this.check3Tr.TabIndex = 0;
            this.check3Tr.Text = "3";
            this.check3Tr.UseVisualStyleBackColor = true;
            // 
            // check5Tr
            // 
            this.check5Tr.AutoSize = true;
            this.check5Tr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check5Tr.ForeColor = System.Drawing.Color.White;
            this.check5Tr.Location = new System.Drawing.Point(173, 3);
            this.check5Tr.Name = "check5Tr";
            this.check5Tr.Size = new System.Drawing.Size(38, 24);
            this.check5Tr.TabIndex = 0;
            this.check5Tr.Text = "5";
            this.check5Tr.UseVisualStyleBackColor = true;
            // 
            // check2Tr
            // 
            this.check2Tr.AutoSize = true;
            this.check2Tr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check2Tr.ForeColor = System.Drawing.Color.White;
            this.check2Tr.Location = new System.Drawing.Point(47, 3);
            this.check2Tr.Name = "check2Tr";
            this.check2Tr.Size = new System.Drawing.Size(38, 24);
            this.check2Tr.TabIndex = 0;
            this.check2Tr.Text = "2";
            this.check2Tr.UseVisualStyleBackColor = true;
            // 
            // check4Tr
            // 
            this.check4Tr.AutoSize = true;
            this.check4Tr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check4Tr.ForeColor = System.Drawing.Color.White;
            this.check4Tr.Location = new System.Drawing.Point(129, 3);
            this.check4Tr.Name = "check4Tr";
            this.check4Tr.Size = new System.Drawing.Size(38, 24);
            this.check4Tr.TabIndex = 0;
            this.check4Tr.Text = "4";
            this.check4Tr.UseVisualStyleBackColor = true;
            // 
            // check1Tr
            // 
            this.check1Tr.AutoSize = true;
            this.check1Tr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check1Tr.ForeColor = System.Drawing.Color.White;
            this.check1Tr.Location = new System.Drawing.Point(3, 3);
            this.check1Tr.Name = "check1Tr";
            this.check1Tr.Size = new System.Drawing.Size(38, 24);
            this.check1Tr.TabIndex = 0;
            this.check1Tr.Text = "1";
            this.check1Tr.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(9, 515);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 24);
            this.label1.TabIndex = 66;
            this.label1.Text = "Nº ordem";
            // 
            // pnlCheckFrente
            // 
            this.pnlCheckFrente.BackColor = System.Drawing.Color.Transparent;
            this.pnlCheckFrente.Controls.Add(this.check4Frente);
            this.pnlCheckFrente.Controls.Add(this.check3Frente);
            this.pnlCheckFrente.Controls.Add(this.check2Frente);
            this.pnlCheckFrente.Controls.Add(this.check1Frente);
            this.pnlCheckFrente.Location = new System.Drawing.Point(354, 611);
            this.pnlCheckFrente.Name = "pnlCheckFrente";
            this.pnlCheckFrente.Size = new System.Drawing.Size(198, 60);
            this.pnlCheckFrente.TabIndex = 68;
            this.pnlCheckFrente.Visible = false;
            // 
            // check4Frente
            // 
            this.check4Frente.AutoSize = true;
            this.check4Frente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.check4Frente.ForeColor = System.Drawing.Color.White;
            this.check4Frente.Location = new System.Drawing.Point(137, 3);
            this.check4Frente.Name = "check4Frente";
            this.check4Frente.Size = new System.Drawing.Size(38, 24);
            this.check4Frente.TabIndex = 0;
            this.check4Frente.Text = "4";
            this.check4Frente.UseVisualStyleBackColor = true;
            // 
            // check3Frente
            // 
            this.check3Frente.AutoSize = true;
            this.check3Frente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.check3Frente.ForeColor = System.Drawing.Color.White;
            this.check3Frente.Location = new System.Drawing.Point(90, 3);
            this.check3Frente.Name = "check3Frente";
            this.check3Frente.Size = new System.Drawing.Size(38, 24);
            this.check3Frente.TabIndex = 0;
            this.check3Frente.Text = "3";
            this.check3Frente.UseVisualStyleBackColor = true;
            // 
            // check2Frente
            // 
            this.check2Frente.AutoSize = true;
            this.check2Frente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.check2Frente.ForeColor = System.Drawing.Color.White;
            this.check2Frente.Location = new System.Drawing.Point(47, 3);
            this.check2Frente.Name = "check2Frente";
            this.check2Frente.Size = new System.Drawing.Size(38, 24);
            this.check2Frente.TabIndex = 0;
            this.check2Frente.Text = "2";
            this.check2Frente.UseVisualStyleBackColor = true;
            // 
            // check1Frente
            // 
            this.check1Frente.AutoSize = true;
            this.check1Frente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.check1Frente.ForeColor = System.Drawing.Color.White;
            this.check1Frente.Location = new System.Drawing.Point(3, 3);
            this.check1Frente.Name = "check1Frente";
            this.check1Frente.Size = new System.Drawing.Size(38, 24);
            this.check1Frente.TabIndex = 0;
            this.check1Frente.Text = "1";
            this.check1Frente.UseVisualStyleBackColor = true;
            // 
            // pnlFechar
            // 
            this.pnlFechar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlFechar.BackColor = System.Drawing.Color.YellowGreen;
            this.pnlFechar.Controls.Add(this.lblFechar);
            this.pnlFechar.Location = new System.Drawing.Point(912, -5);
            this.pnlFechar.Name = "pnlFechar";
            this.pnlFechar.Size = new System.Drawing.Size(44, 25);
            this.pnlFechar.TabIndex = 69;
            // 
            // lblFechar
            // 
            this.lblFechar.AutoSize = true;
            this.lblFechar.BackColor = System.Drawing.Color.Transparent;
            this.lblFechar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblFechar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechar.ForeColor = System.Drawing.Color.SeaShell;
            this.lblFechar.Location = new System.Drawing.Point(6, 7);
            this.lblFechar.Name = "lblFechar";
            this.lblFechar.Size = new System.Drawing.Size(17, 16);
            this.lblFechar.TabIndex = 70;
            this.lblFechar.Text = "X";
            this.lblFechar.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnCalcular1722
            // 
            this.btnCalcular1722.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.btnCalcular1722.Location = new System.Drawing.Point(7, 576);
            this.btnCalcular1722.Name = "btnCalcular1722";
            this.btnCalcular1722.Size = new System.Drawing.Size(112, 33);
            this.btnCalcular1722.TabIndex = 71;
            this.btnCalcular1722.Text = "Calcular";
            this.btnCalcular1722.UseVisualStyleBackColor = true;
            this.btnCalcular1722.Click += new System.EventHandler(this.btnCalcular1722_Click);
            // 
            // btnCalcularAR
            // 
            this.btnCalcularAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.btnCalcularAR.Location = new System.Drawing.Point(7, 576);
            this.btnCalcularAR.Name = "btnCalcularAR";
            this.btnCalcularAR.Size = new System.Drawing.Size(112, 33);
            this.btnCalcularAR.TabIndex = 72;
            this.btnCalcularAR.Text = "Calcular";
            this.btnCalcularAR.UseVisualStyleBackColor = true;
            this.btnCalcularAR.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // txtModelo
            // 
            this.txtModelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.txtModelo.Location = new System.Drawing.Point(5, 488);
            this.txtModelo.Name = "txtModelo";
            this.txtModelo.ReadOnly = true;
            this.txtModelo.Size = new System.Drawing.Size(112, 26);
            this.txtModelo.TabIndex = 73;
            this.txtModelo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(28, 461);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 24);
            this.label2.TabIndex = 74;
            this.label2.Text = "Modelo";
            // 
            // combNordem
            // 
            this.combNordem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combNordem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.combNordem.FormattingEnabled = true;
            this.combNordem.Items.AddRange(new object[] {
            "",
            "58001",
            "58003",
            "58006",
            "58007",
            "58008",
            "58009",
            "58010",
            "58011",
            "58012",
            "58013",
            "58014",
            "58016",
            "58017",
            "58019",
            "58020",
            "58022",
            "58023",
            "58024",
            "58025",
            "58027",
            "58028",
            "58031",
            "58032",
            "58033",
            "58034",
            "58035",
            "58039",
            "58040",
            "58042",
            "58043",
            "58044",
            "58046",
            "58047",
            "58048",
            "58049",
            "58052",
            "58053",
            "58054",
            "58055",
            "58056",
            "58058",
            "58059",
            "58060",
            "58061",
            "58063",
            "58065",
            "58070",
            "58073",
            "58075",
            "58076",
            "58077",
            "58078",
            "58079",
            "58081",
            "58084",
            "58085",
            "58088",
            "58089",
            "58091",
            "58092",
            "58094",
            "58095",
            "58096",
            "58097",
            "58098",
            "58100",
            "58102",
            "58103",
            "58105",
            "58106",
            "58110",
            "58111",
            "58113",
            "58114",
            "58115",
            "58116",
            "58117",
            "58118",
            "58119",
            "58120",
            "58121",
            "58122",
            "58123",
            "58124",
            "58125",
            "58127",
            "58128",
            "58131",
            "58132",
            "58135",
            "58147",
            "58150",
            "58151",
            "58152",
            "58153",
            "58155",
            "58157",
            "58160",
            "58161",
            "58162",
            "58163",
            "58164",
            "58165",
            "58166",
            "58167",
            "58168",
            "58169",
            "58171",
            "58172",
            "58173",
            "58174",
            "58177",
            "58178",
            "58185",
            "58188",
            "58189",
            "58190",
            "58204",
            "58205",
            "58207",
            "58210",
            "58211",
            "58214",
            "58215",
            "58216",
            "58217"});
            this.combNordem.Location = new System.Drawing.Point(5, 542);
            this.combNordem.Name = "combNordem";
            this.combNordem.Size = new System.Drawing.Size(114, 28);
            this.combNordem.TabIndex = 75;
            this.combNordem.SelectedIndexChanged += new System.EventHandler(this.combNordem_SelectedIndexChanged);
            // 
            // btnPesquisarAvaria
            // 
            this.btnPesquisarAvaria.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnPesquisarAvaria.Location = new System.Drawing.Point(7, 661);
            this.btnPesquisarAvaria.Name = "btnPesquisarAvaria";
            this.btnPesquisarAvaria.Size = new System.Drawing.Size(112, 33);
            this.btnPesquisarAvaria.TabIndex = 76;
            this.btnPesquisarAvaria.Text = "Pesquisar";
            this.btnPesquisarAvaria.UseVisualStyleBackColor = true;
            this.btnPesquisarAvaria.Click += new System.EventHandler(this.btnPesquisarAvaria_Click);
            // 
            // AvariaAR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = global::Empresa2.Properties.Resources._1519Ar_condicionado1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(940, 719);
            this.Controls.Add(this.btnPesquisarAvaria);
            this.Controls.Add(this.combNordem);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtModelo);
            this.Controls.Add(this.btnCalcularAR);
            this.Controls.Add(this.btnCalcular1722);
            this.Controls.Add(this.pnlFechar);
            this.Controls.Add(this.pnlCheckFrente);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pnlCheckTraseira);
            this.Controls.Add(this.rbTraseira);
            this.Controls.Add(this.checkP);
            this.Controls.Add(this.checkCP);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.rbDianteira);
            this.Controls.Add(this.btnNovaAvaria);
            this.Controls.Add(this.rbLE);
            this.Controls.Add(this.rbLD);
            this.Controls.Add(this.pnlCheckLD);
            this.Controls.Add(this.pnlCheckLE);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AvariaAR";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Controle";
            this.Load += new System.EventHandler(this.AvariaAR_Load);
            this.pnlCheckLD.ResumeLayout(false);
            this.pnlCheckLD.PerformLayout();
            this.pnlCheckLE.ResumeLayout(false);
            this.pnlCheckLE.PerformLayout();
            this.pnlCheckTraseira.ResumeLayout(false);
            this.pnlCheckTraseira.PerformLayout();
            this.pnlCheckFrente.ResumeLayout(false);
            this.pnlCheckFrente.PerformLayout();
            this.pnlFechar.ResumeLayout(false);
            this.pnlFechar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.CheckBox check1LD;
        private System.Windows.Forms.CheckBox check2LD;
        private System.Windows.Forms.Button btnNovaAvaria;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Panel pnlCheckLD;
        private System.Windows.Forms.CheckBox check3LD;
        private System.Windows.Forms.CheckBox check6LD;
        private System.Windows.Forms.CheckBox check5LD;
        private System.Windows.Forms.CheckBox check4LD;
        private System.Windows.Forms.RadioButton rbLD;
        private System.Windows.Forms.RadioButton rbLE;
        private System.Windows.Forms.RadioButton rbDianteira;
        private System.Windows.Forms.CheckBox checkCP;
        private System.Windows.Forms.CheckBox checkP;
        private System.Windows.Forms.RadioButton rbTraseira;
        private System.Windows.Forms.CheckBox check12LD;
        private System.Windows.Forms.CheckBox check11LD;
        private System.Windows.Forms.CheckBox check10LD;
        private System.Windows.Forms.CheckBox check9LD;
        private System.Windows.Forms.CheckBox check8LD;
        private System.Windows.Forms.CheckBox check7LD;
        private System.Windows.Forms.CheckBox check14LD;
        private System.Windows.Forms.CheckBox check13LD;
        private System.Windows.Forms.CheckBox check17LD;
        private System.Windows.Forms.CheckBox check16LD;
        private System.Windows.Forms.CheckBox check15LD;
        private System.Windows.Forms.Panel pnlCheckLE;
        private System.Windows.Forms.CheckBox check18LE;
        private System.Windows.Forms.CheckBox check17LE;
        private System.Windows.Forms.CheckBox check16LE;
        private System.Windows.Forms.CheckBox check15LE;
        private System.Windows.Forms.CheckBox check14LE;
        private System.Windows.Forms.CheckBox check13LE;
        private System.Windows.Forms.CheckBox check12LE;
        private System.Windows.Forms.CheckBox check11LE;
        private System.Windows.Forms.CheckBox check10LE;
        private System.Windows.Forms.CheckBox check9LE;
        private System.Windows.Forms.CheckBox check8LE;
        private System.Windows.Forms.CheckBox check7LE;
        private System.Windows.Forms.CheckBox check6LE;
        private System.Windows.Forms.CheckBox check5LE;
        private System.Windows.Forms.CheckBox check4LE;
        private System.Windows.Forms.CheckBox check3LE;
        private System.Windows.Forms.CheckBox check2LE;
        private System.Windows.Forms.CheckBox check1LE;
        private System.Windows.Forms.Panel pnlCheckTraseira;
        private System.Windows.Forms.CheckBox check6Tr;
        private System.Windows.Forms.CheckBox check3Tr;
        private System.Windows.Forms.CheckBox check5Tr;
        private System.Windows.Forms.CheckBox check2Tr;
        private System.Windows.Forms.CheckBox check4Tr;
        private System.Windows.Forms.CheckBox check1Tr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlCheckFrente;
        private System.Windows.Forms.CheckBox check1Frente;
        private System.Windows.Forms.CheckBox check4Frente;
        private System.Windows.Forms.CheckBox check3Frente;
        private System.Windows.Forms.CheckBox check2Frente;
        private System.Windows.Forms.CheckBox check0LD;
        private System.Windows.Forms.CheckBox check19LE;
        private System.Windows.Forms.Panel pnlFechar;
        private System.Windows.Forms.Label lblFechar;
        private System.Windows.Forms.Button btnCalcular1722;
        private System.Windows.Forms.Button btnCalcularAR;
        private System.Windows.Forms.TextBox txtModelo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox combNordem;
        private System.Windows.Forms.Button btnPesquisarAvaria;
    }
}