﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace Empresa2
{
    public partial class frmPrincipal : Form
    {
        string senhaC = "controle0101";
        string senhajc = "044194";
        string senhaA = "anotador00";
        public frmPrincipal()
        {
            InitializeComponent();      
        
        }

      
         

        private void txtIdentificador_TextChanged(object sender, EventArgs e)
        {          
            
            if (txtUsuario.Text == "anotador")
            {                

                lblSenha.Visible = true; // Ativa a visibilidade da Label Senha
                lblSenha.Enabled = true; // Ativa a Label senha

                txtSenha.Enabled = true; // Ativa o textbox para digitar senha
                txtSenha.Visible = true; // Ativa a visibilidade do textbox para digitar a senha

                btnEntrar.Visible = true; // Ativa a visibilidade do botão entrar
                btnEntrar.Enabled = true; // Ativa o botão entrar 
                                
            }

            if (txtUsuario.Text == "controle") // Se o usuario digitar controle no login
            {
                lblSenha.Visible = true; // Ativa a visibilidade da Label Senha
                lblSenha.Enabled = true; // Ativa a Label senha

                txtSenha.Enabled = true; // Ativa o textbox para digitar senha
                txtSenha.Visible = true; // Ativa a visibilidade do textbox para digitar a senha

                btnEntrar.Visible = true; // Ativa a visibilidade do botão entrar
                btnEntrar.Enabled = true; // Ativa o botão entrar                
                            
            }

            if(txtUsuario.Text != "anotador")
            {
                imgDesfoque.Visible = false;
                imgDesfoque.Enabled = false;
            }

            if (txtUsuario.Text != "controle" && txtUsuario.Text != "anotador")
            {
                lblSenha.Visible = false;
                txtSenha.Visible = false;
                btnEntrar.Visible = false;
                imgDesfoque.Visible = false;
                imgDesfoque.Enabled = false;

                txtSenha.Clear();
            }         

                                 

        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {            

            if(txtSenha.Text != senhaC && txtUsuario.Text == "controle" && txtSenha.Text != "")
            {
                MessageBox.Show("Senha incorreta!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if(txtSenha.Text == "" && txtSenha.Text != senhaC && txtUsuario.Text == "controle")
            {
                MessageBox.Show("Você não digitou a senha", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (txtSenha.Text == senhaC)
            {
                imgDesfoque.Visible = true;
                imgDesfoque.Enabled = true;

                txtSenha.Enabled = false;
                txtSenha.Visible = false;

                lblSenha.Visible = false;
                lblSenha.Enabled = false;

                btnEntrar.Visible = false;
                btnEntrar.Enabled = false;

                AvariaAR NovaAvaria = new AvariaAR();
                NovaAvaria.ShowDialog();

            }


            if (txtSenha.Text != senhaA && txtUsuario.Text == "anotador")
            {
                MessageBox.Show("Senha incorreta!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (txtSenha.Text == senhaA && txtUsuario.Text == "anotador")
            {
                imgDesfoque.Visible = true;
                imgDesfoque.Enabled = true;

                txtSenha.Enabled = false;
                txtSenha.Visible = false;

                lblSenha.Visible = false;
                lblSenha.Enabled = false;

                btnEntrar.Visible = false;
                btnEntrar.Enabled = false;

                manutencao avariaanotador = new manutencao();

                avariaanotador.ShowDialog();

            }

        }

        private void txtSenha_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtUsuario.Text == "anotador" && txtSenha.Text == senhaA)
            {
                imgDesfoque.Visible = true; // Ativa a visibilidade da imagem desfocada

                imgDesfoque.Enabled = true; // Desativa a imagem desfocada

                txtSenha.Enabled = false; // Destiva a caixa de texto com a senha

                txtSenha.Visible = false;  // Desativa a visibilidade da caixa de texto com a senha

                lblSenha.Visible = false; // Desativa a visibilidade da label Senha

                lblSenha.Enabled = false; //Desativa a Label Senha

                btnEntrar.Visible = false; // Desativa a visibilidade do botão Entrar

                btnEntrar.Enabled = false; //Desativa o botão entrar

                manutencao avariaanotador = new manutencao(); 

                avariaanotador.ShowDialog();
            }

            if (e.KeyCode == Keys.Enter && txtUsuario.Text == "anotador" && txtSenha.Text == "")
            {
                MessageBox.Show("Você não digitou a senha", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }

            if (e.KeyCode == Keys.Enter && txtUsuario.Text == "anotador" && txtSenha.Text != "" && txtSenha.Text != senhaA)
            {
                MessageBox.Show("Senha incorreta", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



            if (e.KeyCode == Keys.Enter && txtUsuario.Text == "controle" && txtSenha.Text == senhaC)
            {
                imgDesfoque.Visible = true; // Ativa a visibilidade da imagem desfocada

                imgDesfoque.Enabled = true; // Desativa a imagem desfocada

                txtSenha.Enabled = false; // Destiva a caixa de texto com a senha

                txtSenha.Visible = false;  // Desativa a visibilidade da caixa de texto com a senha

                lblSenha.Visible = false; // Desativa a visibilidade da label Senha

                lblSenha.Enabled = false; //Desativa a Label Senha

                btnEntrar.Visible = false; // Desativa a visibilidade do botão Entrar

                btnEntrar.Enabled = false; //Desativa o botão entrar

                AvariaAR NovaAvaria = new AvariaAR();
                NovaAvaria.ShowDialog();
            }

            if (e.KeyCode == Keys.Enter && txtUsuario.Text == "controle" && txtSenha.Text == "")
            {
                MessageBox.Show("Você não digitou a senha", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (e.KeyCode == Keys.Enter && txtUsuario.Text == "controle" && txtSenha.Text != "" && txtSenha.Text != senhaC)
            {
                MessageBox.Show("Senha incorreta", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void txtUsuario_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && txtUsuario.Text == "anotador" && txtSenha.Text == senhaA)
            {
                imgDesfoque.Visible = true; // Ativa a visibilidade da imagem desfocada

                imgDesfoque.Enabled = true; // Desativa a imagem desfocada

                txtSenha.Enabled = false; // Destiva a caixa de texto com a senha

                txtSenha.Visible = false;  // Desativa a visibilidade da caixa de texto com a senha

                lblSenha.Visible = false; // Desativa a visibilidade da label Senha

                lblSenha.Enabled = false; //Desativa a Label Senha

                btnEntrar.Visible = false; // Desativa a visibilidade do botão Entrar

                btnEntrar.Enabled = false; //Desativa o botão entrar

                manutencao avariaanotador = new manutencao();

                avariaanotador.ShowDialog();

                this.Visible = false;
            }

            if (e.KeyCode == Keys.Enter && txtUsuario.Text == "anotador" && txtSenha.Text == "")
            {
                MessageBox.Show("Você não digitou a senha", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }

            if (e.KeyCode == Keys.Enter && txtUsuario.Text == "anotador" && txtSenha.Text != "" && txtSenha.Text != senhaA)
            {
                MessageBox.Show("Senha incorreta", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



            if (e.KeyCode == Keys.Enter && txtUsuario.Text == "controle" && txtSenha.Text == senhaC)
            {
                imgDesfoque.Visible = true; // Ativa a visibilidade da imagem desfocada

                imgDesfoque.Enabled = true; // Desativa a imagem desfocada

                txtSenha.Enabled = false; // Destiva a caixa de texto com a senha

                txtSenha.Visible = false;  // Desativa a visibilidade da caixa de texto com a senha

                lblSenha.Visible = false; // Desativa a visibilidade da label Senha

                lblSenha.Enabled = false; //Desativa a Label Senha

                btnEntrar.Visible = false; // Desativa a visibilidade do botão Entrar

                btnEntrar.Enabled = false; //Desativa o botão entrar

                AvariaAR NovaAvaria = new AvariaAR();
                NovaAvaria.ShowDialog();
            }

            if (e.KeyCode == Keys.Enter && txtUsuario.Text == "controle" && txtSenha.Text == "")
            {
                MessageBox.Show("Você não digitou a senha", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (e.KeyCode == Keys.Enter && txtUsuario.Text == "controle" && txtSenha.Text != "" && txtSenha.Text != senhaC)
            {
                MessageBox.Show("Senha incorreta", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {

        }
    }
}
       
    
