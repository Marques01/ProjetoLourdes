﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa2
{
    public class Calcular1519
    {
public double chapa90 = 190.80;
        public double chapa75 = 182.00;
        public double washprimer = 30.93;
        public double catalizador = 14.81;
        public double chapelco = 149.75;
        public double m60 = 155.64;
        public double cidadeRJ = 40.00;
        public double internorte = 8.00;
        public double nordem = 2.50;
        public double nordemg = 0.50;
        public double nordemt = 1.00;
        public double papel = 22.40;
        public double capsula = 4.00;
        public double seta = 4.00;
        public double cadeirante = 5.50;
        public double faixarefletiva = 2.95;
        public double peixinho = 6.50;
        public double duplaface = 63.66;
        public double fitafina = 3.71;
        public double fitagrossa = 10.82;
        public double trincob = 3.20;
        public double trincot = 29.24;
        public double peixao = 12.34;
        public double dobradicaLD = 26.00;
        public double dobradicaLE = 30.00;
        public double puxador = 10.90;
        public double massapoliester = 19.71;
        public double massafibra = 29.08;
        public double tintaverde = 37.55;
        public double catalisadormassa = 7.00;
        public double tintapreta = 65.86;
        public double redutor = 84.76;
        public double cidadeRJgrade = 3.00;
        public double disco80 = 3.45;
        public double cinzaarofarol = 51.92;
        public double chapafurada = 271.89;

        public double total_check1_1519()
        {
            double total_check1_1519 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + capsula + faixarefletiva;

            return total_check1_1519;

            // Valor cobrado check1 Lado Direito
        }

        public double total_check2_1519()
        {
            double total_check2_1519 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + cidadeRJ + faixarefletiva;

            return total_check2_1519;

            // Valor cobrado check2 Lado Direito
        }

        public double total_check3_1519()
        {
            double total_check3_1519 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + cadeirante + faixarefletiva;

            return total_check3_1519;

            // Valor cobrado check3 Lado Direito
        }
    }
}
