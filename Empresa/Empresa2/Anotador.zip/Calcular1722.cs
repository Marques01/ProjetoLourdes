﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa2
{
    public class Calcular1722
    {
        public double chapa90 = 190.80;
        public double chapa75 = 182.00;
        public double washprimer = 30.93;
        public double catalizador = 14.81;
        public double chapelco = 149.75;
        public double m60 = 155.64;
        public double cidadeRJ = 40.00;
        public double internorte = 8.00;
        public double nordem = 2.50;
        public double nordemg = 0.50;
        public double nordemt = 1.00;
        public double papel = 22.40;
        public double capsula = 4.00;
        public double seta = 4.00;
        public double cadeirante = 5.50;
        public double faixarefletiva = 2.95;
        public double peixinho = 6.50;
        public double duplaface = 63.66;
        public double fitafina = 3.71;
        public double fitagrossa = 10.82;
        public double trincob = 3.20;
        public double trincot = 29.24;
        public double peixao = 12.34;
        public double dobradicaLD = 26.00;
        public double dobradicaLE = 30.00;
        public double puxador = 10.90;
        public double massapoliester = 19.71;
        public double massafibra = 29.08;
        public double tintaverde = 37.55;
        public double catalisadormassa = 7.00;
        public double tintapreta = 65.86;
        public double redutor = 84.76;
        public double cidadeRJgrade = 3.00;
        public double disco80 = 3.45;
        public double cinzaarofarol = 51.92;
        public double chapafurada = 271.89;

        public double total_check0_1722()
        {
            double total_check0_1722 = (massafibra / 2) + (massapoliester / 2) + (m60 * 0.20) + faixarefletiva + (2 * disco80) + (papel / 2) + fitafina + (redutor * 0.05);

            return total_check0_1722;

            // Valor cobrado do check1 Lado Direito
        }    
        public double total_check1_1722()
        {
            double total_check1_1722 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + capsula + faixarefletiva;

            return total_check1_1722;

            // Valor cobrado do check1 Lado Direito
        }
        public double total_check2_1722()
        {
           double total_check2_1722 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + cidadeRJ + faixarefletiva;

           return total_check2_1722;

           // Valor cobrado do check2 Lado Direito 
        }
        public double total_check3_1722()
        {
            double total_check3_1722 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + cidadeRJ + faixarefletiva;

            return total_check3_1722;

            // Valor cobrado do check3 Lado Direito
        }
        public double total_check4_1722()
        {
            double total_check4_1722 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + internorte + faixarefletiva + cadeirante;

            return total_check4_1722;

            // Valor cobrado do check4 Lado Direito
        }

        public double total_check5_1722()
        {
            double total_check5_1722 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (5 * nordem) + faixarefletiva + seta;

            return total_check5_1722;

            // Valor cobrado do check5 Lado Direito
        }

        public double total_check6_1722()
        {
            double total_check6_1722 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + nordem + faixarefletiva + seta;

            return total_check6_1722;

            // Valor cobrado do check6 Lado Direito
        }
        public double total_check7_1722()
        {
            double total_check7_1722 = (chapa75 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + peixinho;

            return total_check7_1722;

            // Valor cobrado do check7 Lado Direito
        }
        
        public double total_check8_1722()
        {
            double total_check8_1722 = (chapa75 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.10 * m60);

            return total_check8_1722;

            // Valor cobrado do check8 Lado Direito
        }
        public double total_check9_1722()
        {
            double total_check9_1722 = (chapa75 / 4) + (0.1 * chapelco) + (0.2 * washprimer) + (0.25 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.05 * m60);

            return total_check9_1722;

            // Valor cobrado do check9 Lado Direito
        }

        public double total_check10_1722()
        {
            double total_check10_1722 = (chapa75 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.10 * m60) + peixinho; ;


            return total_check10_1722;

            // Valor cobrado do check10 Lado Direito

        }

        public double total_check11_1722()
        {
            double total_check11_1722 = (chapa75 / 3) + (0.1 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.05 * m60);

            return total_check11_1722;

            // Valor cobrado do check11 Lado Direito
        }

        public double total_check12_1722()
        {
            double total_check12_1722 = (chapa75 / 3) + (0.1 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.05 * m60);

            return total_check12_1722;

            // Valor cobrado do check12 lado Direito
        }

        public double total_check13_1722()
        {
            double total_check13_1722 = (chapa75 / 5) + (0.1 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.025 * m60) + peixinho;

            return total_check13_1722;
            
            // Valor cobrado do check13 Lado Direito
        }

        public double total_check14_1722()
        {
            double total_check14_1722 = (chapa75 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.10 * m60) + (2 * trincot) + dobradicaLD + dobradicaLE + (2 * puxador);

            return total_check14_1722;

            // Valor cobrado do check14 Lado Direito
        }

        public double total_check15_1722()
        {
            double total_check15_1722 = (chapa75 / 5) + (0.1 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.05 * m60);

            return total_check15_1722;

            // Valor cobrado do check15 Lado Direito
        }

        public double total_check16_1722()
        {
            double total_check16_1722 = (chapa75 / 5) + (0.1 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.05 * m60);

            return total_check16_1722;

            // valor cobrado do check16 Lado Direito 
        }

        public double total_check17_1722()
        {
            double total_check17_1722 = (chapa75 / 4) + (0.1 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.05 * m60) + peixao;

            return total_check17_1722;

            // Valor cobrado do check17 Lado Direito
        }

        // Lado Esquerdo

        public double total_check1LE_1722()
        {

            double total_check1LE_1722 = chapafurada + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.25 * duplaface) + faixarefletiva;

            return total_check1LE_1722;

            // Valor cobrado do check1 Lado Esquerdo

            
        }

        public double total_check2LE_1722()
        {
            double total_check2LE_1722 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.25 * duplaface) + capsula + (faixarefletiva * 2) + (6 * nordem);

            return total_check2LE_1722;

            // Valor cobrado check2 Lado Esquerdo

        }

        public double total_check3LE_1722()
        {
            double total_check3LE_1722 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + internorte + faixarefletiva;

            return total_check3LE_1722;

            // Valor cobrado check3 Lado Esquerdo

        }

        public double total_check4LE_1722()
        {
            double total_check4LE_1722 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + capsula;

            return total_check4LE_1722;

            // Valor cobrado check4 Lado Esquerdo
            
        }

        public double total_check5LE_1722()
        {

            double total_check5LE_1722 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + faixarefletiva;

            return total_check5LE_1722;

            // Valor cobrado check5 Lado Esquerdo
        }

        public double total_check6LE_1722()
        {
            double total_check6LE_1722 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + cidadeRJ;

            return total_check6LE_1722;

            // Valor cobrado check6 Lado esquerdo
        }

        public double total_check7LE_1722()
        {
            double total_check6LE_1722 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + cidadeRJ + cadeirante;

            return total_check6LE_1722;

            // Valor cobrado check7 lado Esquerdo
        }

        public double total_check8LE_1722()
        {
            double total_check8LE_1722 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + capsula;

            return total_check8LE_1722;

            // Valor cobrado check8 Lado Esquerdo
        }

        public double total_check9LE_1722()
        {
            double total_check9LE_1722 = (chapa75 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.10 * m60) + (2 * trincob) + puxador + dobradicaLE + dobradicaLD;

            return total_check9LE_1722;

            // Valor cobrado check9 Lado Esquerdo
        }
        

        public double total_check10LE_1722()
        {
            double total_check10LE_1722 = (chapa75 / 3) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.05 * m60) + peixao;

            return total_check10LE_1722;

            // Valor cobrado check10 Lado Esquerdo
        }

        public double total_check11LE_1722()
        {
            double total_check11LE_1722 = (chapa75 / 4) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.05 * m60);

            return total_check11LE_1722;

            // Valor cobrado check11 Lado Esquerdo
        }

        public double total_check12LE_1722()
        {
            double total_check12LE_1722 = (chapa75 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.10 * m60) + (2 * trincob) + puxador + dobradicaLD + dobradicaLE;

            return total_check12LE_1722;

            // valor cobrado check12 Lado Esquerdo
        }

        public double total_check13LE_1722()
        {
            double total_check13LE_1722 = (chapa75 / 3) + (0.1 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.10 * m60) + peixinho;

            return total_check13LE_1722;

            // Valor cobrado check13 Lado Esquerdo
        }

        public double total_check14LE_1722()
        {

            double total_check14LE_1722 = (chapa75 / 2) + (0.1 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.10 * m60) + (2 * trincot) + dobradicaLE + dobradicaLD + (2 * puxador);

            return total_check14LE_1722;

            // Valor cobrado do check14 Lado Esquerdo
        }

        public double total_check15LE_1722()
        {
            double total_check15LE_1722 = (chapa75 / 3) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.10 * m60) + peixinho;

            return total_check15LE_1722;

            // Valor cobrado check15 Lado Esquerdo
        }

        public double total_check16LE_1722()
        {
            double total_check16LE_1722 = (chapa75 / 4) + (0.1 * chapelco) + (0.2 * washprimer) + (0.25 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.05 * m60);

            return total_check16LE_1722;

            // Valor cobrado check16 Lado Esquerdo
        }

        public double total_check17LE_1722()
        {
            double total_check17LE_1722 = (chapa75 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (0.10 * m60);

            return total_check17LE_1722;

            // Valor cobrado check17 Lado Esquerdo
        }

        public double total_check18LE_1722()
        {
            double total_check18LE_1722 = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + peixinho;

            return total_check18LE_1722;

            // Valor cobrado check18 lado Esquerdo
        }

        public double total_check19LE_1722()
        {
            double total_check19LE_1722 = (massafibra / 2) + (massapoliester / 2) + (m60 * 0.20) + faixarefletiva + (2 * disco80) + (papel / 2) + fitafina + (redutor * 0.05);

            return total_check19LE_1722;

            // Valor cobrado check19 Lado Esquerdo
        }


}

}
