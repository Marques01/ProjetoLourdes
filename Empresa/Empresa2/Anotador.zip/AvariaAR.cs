﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Windows.Forms.VisualStyles;

namespace Empresa2
{
    public partial class AvariaAR : Form
    {
        string av = "O valor total da avaria foi de R$:";
         double chapa90 = 190.80;
         double chapa75 = 182.00;
         double washprimer = 30.93;
         double catalizador = 14.81;
         double chapelco = 149.75;
         double m60 = 155.64;
         double cidadeRJ = 40.00;
         double internorte = 8.00;
         double nordem = 2.50;
         double nordemg = 0.50;
         double nordemt = 1.00;
         double papel = 22.40;
         double capsula = 4.00;
         double seta = 4.00;
         double cadeirante = 5.50;
         double faixarefletiva = 2.95;
         double peixinho = 6.50;
         double duplaface = 63.66;
         double fitafina = 3.71;
         double fitagrossa = 10.82;
         double trincob = 3.20;
         double trincot = 29.24;
         double peixao = 12.34;
         double dobradicaLD = 26.00;
         double dobradicaLE = 30.00;
         double puxador = 10.90;
         double massapoliester = 19.71;
         double massafibra = 29.08;
         double tintaverde = 37.55;
         double catalisadormassa = 7.00;
         double tintapreta = 65.86;
         double redutor = 84.76;
         double cidadeRJgrade = 3.00;
         double disco80 = 3.45;
         double cinzaarofarol = 51.92;
         double chapafurada = 271.89;
         double total;

        Calcular1722 c1722 = new Calcular1722();
        CalcularArCondiconado car = new CalcularArCondiconado();
        CalcularDianteira_Traseira cdt = new CalcularDianteira_Traseira();
        Calcular1519 c1519 = new Calcular1519();


        public AvariaAR()
        {

            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e) // Botão de nova avaria
        {
            const string newav = "Selecione o tipo de avaria \nO(s) número(s) da(s) chapa(s) e clique em calcular.";

            MessageBox.Show(newav, "Nova avaria", MessageBoxButtons.OK, MessageBoxIcon.Information); // Mensagem exibida


            if (txtModelo.Text == "Ar condicionado")
            {               

                btnCalcularAR.Visible = true; // Ativa a visibilidade do botão calcular do ar condicionado

                btnCalcular1722.Visible = false; // Desativa a visibilidade do botão calcular 1722

                btnCalcular.Visible = false; // Desativa a visibilidade do botão calcular 1519          
            }

            if (txtModelo.Text == "1722")
            {
                btnCalcularAR.Visible = false; // Desativa a visibilidade do botão calcular do ar condicionado

                btnCalcular1722.Visible = true; // Ativa a visibilidade do botão calcular 1722

                btnCalcular.Visible = false; // Desativa a visibilidade do botão calcular 1519

            }

            if (txtModelo.Text == "1519")
            {
                btnCalcularAR.Visible = false; // Desativa a visibilidade do botão calcular do ar condicionado

                btnCalcular1722.Visible = false; // Desativa a visibilidade do botão calcular 1722

                btnCalcular.Visible = true; // Ativa a visibilidade do botão calcular 1519

            }


            if (combNordem.SelectedItem.Equals("58001") || combNordem.SelectedItem.Equals("58003") || combNordem.SelectedItem.Equals("58011") || combNordem.SelectedItem.Equals("58014") || combNordem.SelectedItem.Equals("58019") || combNordem.SelectedItem.Equals("58020") || combNordem.SelectedItem.Equals("58023")
                || combNordem.SelectedItem.Equals("58023") || combNordem.SelectedItem.Equals("58033") || combNordem.SelectedItem.Equals("58042") || combNordem.SelectedItem.Equals("58049") || combNordem.SelectedItem.Equals("58053") || combNordem.SelectedItem.Equals("58054") || combNordem.SelectedItem.Equals("58061")
                || combNordem.SelectedItem.Equals("58065") || combNordem.SelectedItem.Equals("58070") || combNordem.SelectedItem.Equals("58073") || combNordem.SelectedItem.Equals("58077") || combNordem.SelectedItem.Equals("58078") || combNordem.SelectedItem.Equals("58079") || combNordem.SelectedItem.Equals("58089")
                || combNordem.SelectedItem.Equals("58091") || combNordem.SelectedItem.Equals("58092") || combNordem.SelectedItem.Equals("58098") || combNordem.SelectedItem.Equals("58102") || combNordem.SelectedItem.Equals("58110") || combNordem.SelectedItem.Equals("58111") || combNordem.SelectedItem.Equals("58118")
                || combNordem.SelectedItem.Equals("58122") || combNordem.SelectedItem.Equals("58131") || combNordem.SelectedItem.Equals("58132") || combNordem.SelectedItem.Equals("58135") || combNordem.SelectedItem.Equals("58150") || combNordem.SelectedItem.Equals("58152") || combNordem.SelectedItem.Equals("58153")
                || combNordem.SelectedItem.Equals("58155") || combNordem.SelectedItem.Equals("58157") || combNordem.SelectedItem.Equals("58160") || combNordem.SelectedItem.Equals("58161") || combNordem.SelectedItem.Equals("58162") || combNordem.SelectedItem.Equals("58163") || combNordem.SelectedItem.Equals("58164")
                || combNordem.SelectedItem.Equals("58165") || combNordem.SelectedItem.Equals("58166") || combNordem.SelectedItem.Equals("58174")) // Modelo de carros 1722
            {
                txtModelo.Text = "1722";
            }

            if(combNordem.SelectedItem.Equals("58009") || combNordem.SelectedItem.Equals("58016") || combNordem.SelectedItem.Equals("58017") || combNordem.SelectedItem.Equals("58028") || combNordem.SelectedItem.Equals("58031") || combNordem.SelectedItem.Equals("58058") || combNordem.SelectedItem.Equals("58060")
            || combNordem.SelectedItem.Equals("58081") || combNordem.SelectedItem.Equals("58088") || combNordem.SelectedItem.Equals("58100") || combNordem.SelectedItem.Equals("58103") || combNordem.SelectedItem.Equals("58106") || combNordem.SelectedItem.Equals("58113") || combNordem.SelectedItem.Equals("58114")
            || combNordem.SelectedItem.Equals("58115") || combNordem.SelectedItem.Equals("58116") || combNordem.SelectedItem.Equals("58120") || combNordem.SelectedItem.Equals("58121") || combNordem.SelectedItem.Equals("58125") || combNordem.SelectedItem.Equals("58147") || combNordem.SelectedItem.Equals("58172")
            || combNordem.SelectedItem.Equals("58177") || combNordem.SelectedItem.Equals("58178") || combNordem.SelectedItem.Equals("58185") || combNordem.SelectedItem.Equals("58188") || combNordem.SelectedItem.Equals("58190") || combNordem.SelectedItem.Equals("58204") || combNordem.SelectedItem.Equals("58205")
            || combNordem.SelectedItem.Equals("58207") || combNordem.SelectedItem.Equals("58210") || combNordem.SelectedItem.Equals("58211") || combNordem.SelectedItem.Equals("58214") || combNordem.SelectedItem.Equals("58215") || combNordem.SelectedItem.Equals("58216") || combNordem.SelectedItem.Equals("58217")) //Modelo de carro Ar condicionado
        
            {
                txtModelo.Text = "Ar condicionado";
            }

            if (combNordem.SelectedItem.Equals("58006") || combNordem.SelectedItem.Equals("58007") || combNordem.SelectedItem.Equals("58008") || combNordem.SelectedItem.Equals("58010") || combNordem.SelectedItem.Equals("58012") || combNordem.SelectedItem.Equals("58013") || combNordem.SelectedItem.Equals("58022")
                || combNordem.SelectedItem.Equals("58024") || combNordem.SelectedItem.Equals("58025") || combNordem.SelectedItem.Equals("58027") || combNordem.SelectedItem.Equals("58032") || combNordem.SelectedItem.Equals("58034") || combNordem.SelectedItem.Equals("58035") || combNordem.SelectedItem.Equals("58039")
                || combNordem.SelectedItem.Equals("58040") || combNordem.SelectedItem.Equals("58043") || combNordem.SelectedItem.Equals("58044") || combNordem.SelectedItem.Equals("58046") || combNordem.SelectedItem.Equals("58047") || combNordem.SelectedItem.Equals("58048") || combNordem.SelectedItem.Equals("58052")
                || combNordem.SelectedItem.Equals("58055") || combNordem.SelectedItem.Equals("58056") || combNordem.SelectedItem.Equals("58059") || combNordem.SelectedItem.Equals("58094") || combNordem.SelectedItem.Equals("58095") || combNordem.SelectedItem.Equals("58096") || combNordem.SelectedItem.Equals("58097")
                || combNordem.SelectedItem.Equals("58105") || combNordem.SelectedItem.Equals("58117") || combNordem.SelectedItem.Equals("58119") || combNordem.SelectedItem.Equals("58123") || combNordem.SelectedItem.Equals("58124") || combNordem.SelectedItem.Equals("58127") || combNordem.SelectedItem.Equals("58128")
                || combNordem.SelectedItem.Equals("58151") || combNordem.SelectedItem.Equals("58167") || combNordem.SelectedItem.Equals("58168") || combNordem.SelectedItem.Equals("58169") || combNordem.SelectedItem.Equals("58171") || combNordem.SelectedItem.Equals("58173") || combNordem.SelectedItem.Equals("58189")) // Modelo de carros 1519
            {
                txtModelo.Text = "1519";
            }


            if (rbTraseira.Checked == true) // Se o botão da traseira estiver marcado
            {

                pnlCheckTraseira.Visible = true; // Ativa a visibilidade do painel com os check da traseira                            


                // =================== Lado direito ===================

                foreach (Component Controls in pnlCheckLD.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox do Lado direito
                }

                pnlCheckLD.Visible = false; // Desativa a visibilidade dos Checks do Lado direito

                // =================== Lado Esquerdo ===================

                foreach (Component Controls in pnlCheckLE.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox do Lado Esquerdo
                }

                pnlCheckLE.Visible = false; // Desativa a visiblidade dos check do Lado Esquerdo

                // =================== Dianteira ===================

                foreach (Component Controls in pnlCheckFrente.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox da dianteira
                }

                pnlCheckFrente.Visible = false; // Desativa a visiblidade do painel da dianteira com os checks


            }

            if (rbLD.Checked == true) // Se o botao lado direito estiver marcado
            {
                pnlCheckLD.Visible = true; // Visibilidade do painel dos Checks ativada                               


                // =================== Lado Esquerdo ===================

                foreach (Component Controls in pnlCheckLE.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox do Lado Esquerdo
                }

                pnlCheckLE.Visible = false; // Desativa o painel com os check do Lado Esquerdo

                // =================== Dianteira ===================

                foreach (Component Controls in pnlCheckFrente.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox da dianteira
                }

                pnlCheckFrente.Visible = false; // Desativa a visiblidade do painel da dianteira com os checks

                // =================== Traseira ===================

                foreach (Component Controls in pnlCheckTraseira.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox da traseira
                }

                pnlCheckTraseira.Visible = false; // Desativa a visibilidade com os check da traseira


            }


            if (rbLE.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Se o lado esquerdo estiver marcado e o modelo de carro for ar condicionado quando apertar enter a foto muda para esquerda do ar condicionado
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Ar_condicionado_Lado_Esquerdo1;

                foreach(Component Controls in pnlCheckLE.Controls)
                {
                    (Controls as CheckBox).Visible = true; // Ativa a visibilidade de todas as checkbox do painel
                }
            }

            if (rbLE.Checked == true && txtModelo.Text.Equals("1519"))
            {

                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Lourdes_Lado_Esquerdo; //Se a traseira estiver macada e o modelo for 1519 a foto muda para 1519

                check18LE.Visible = false; // Desativa o check18 Lado Esquerdo

                check19LE.Visible = false; // Desativa o check19 Lado Esquerdo
            }



            if (rbLE.Checked == true && txtModelo.Text.Equals("1722")) // Se o Lado Esquerdo estiver marcado e o modelo do carro for 1722 quando apertar enter muda a foto para Lado Esquerdo do 1722 
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1722_Lado_Esquerdo; // Se o Lado Direito estiver marcado e o modelo for 1722 altera a imagem
            }

            if (rbLE.Checked == true) // Exibide o lado Esquerdo
            {

                pnlCheckLE.Visible = true; // Ativa a visibilidade do painel com os check Lado Esquerdo

                // =================== Lado direito ===================

                foreach (Component Controls in pnlCheckLD.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox do Lado direito
                }

                pnlCheckLD.Visible = false; // Desativa o painel responsável pela exibição dos checks

                // =================== Dianteira ===================

                foreach (Component Controls in pnlCheckFrente.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox da dianteira
                }

                pnlCheckFrente.Visible = false; // Desativa a visiblidade do painel da dianteira com os checks

                // =================== Traseira ===================

                foreach (Component Controls in pnlCheckTraseira.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox da traseira
                }

                pnlCheckTraseira.Visible = false; // Desativa a visibilidade com os check da traseira

            }

            if (rbTraseira.Checked == true && txtModelo.Text.Equals("1519"))
            {

                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Lourdes_Traseira; //Se a traseira estiver macada e o modelo for 1519 a foto muda para 1519
            }

            
            if (rbDianteira.Checked == true && txtModelo.Text.Equals("1519"))
            {

                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Lourdes_Frente; //Se a dianteira estiver macada e o modelo for 1519 a foto muda para 1519
            }


            if (rbDianteira.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Se a frente estiver marcada e o modelo de carro for ar condicionado quando apertar enter a foto muda para frente do ar condicionado
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Ar_condicionado_Frente1;
            }


            if (rbDianteira.Checked == true && txtModelo.Text.Equals("1722")) // Se a frente estiver marcada e o modelo do carro for 1722 quando apertar enter muda a foto para frente do 1722 
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1722_Frente; // Se a frente estiver marcada e o modelo for 1722 altera a imagem
            }


            if (rbTraseira.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Se a traseira estiver marcada e o modelo de carro for ar condicionado quando apertar enter a foto muda para traseira do ar condicionado
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Ar_condicionado_Traseira1;
                
            }


            if (rbTraseira.Checked == true && txtModelo.Text.Equals("1722")) // Se a traseira estiver marcada e o modelo do carro for 1722 quando apertar enter muda a foto para traseira do 1722 
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1722_Traseira; // Se a traseira estiver marcada e o modelo for 1722 altera a imagem
            }


            if (rbLD.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Se o lado direito estiver marcado e o modelo de carro for ar condicionado quando apertar enter a foto muda para direita do ar condicionado
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Ar_condicionado_Lado_Direito1;

                foreach (Component Controls in pnlCheckLD.Controls)
                {
                    (Controls as CheckBox).Visible = true;
                }
            }

            if (rbLD.Checked == true && txtModelo.Text.Equals("1722")) // Se o Lado Direito estiver marcado e o modelo do carro for 1722 quando apertar enter muda a foto para Lado Direito do 1722 
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1722_Lado_Direito; // Se o Lado Direito estiver marcado e o modelo for 1722 altera a imagem

                check15LD.Visible = false; // Desativa a visiblidade do check15

                check16LD.Visible = false; // Desativa a visiblidade do check16

                check17LD.Visible = false; // Desativa a visiblidade do check17
            }


            if (rbLD.Checked == true && txtModelo.Text.Equals("1519"))
            {

                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Lourdes_Lado_Direito; //Se o lado Direito estiver marcado e o modelo for 1519 a foto muda para 1519

                check15LD.Visible = true; // Ativa a visiblidade do check15
                
                check16LD.Visible = false; // Desativa o check16 Lado Direito

                check17LD.Visible = false; // Desativa o check17 Lado Direito
            }


            if (rbDianteira.Checked == true) // Se o botao da dianteira estiver marcado
            {

                pnlCheckFrente.Visible = true;


                pnlCheckTraseira.Visible = false; // Desativa a visibilidade com os check da traseira


                pnlCheckLD.Visible = false; // Desativa a visibilidade dos Checks do Lado direito

                pnlCheckLE.Visible = false; // Desativa a visibilidade do painel com os check do Lado Esquerdo


                // =================== Lado direito ===================

                foreach (Component Controls in pnlCheckLD.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox do Lado direito
                }

                // =================== Lado Esquerdo ===================

                foreach (Component Controls in pnlCheckLE.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox do Lado Esquerdo
                }

                // =================== Traseira ===================

                foreach (Component Controls in pnlCheckTraseira.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox da traseira
                }


            }


        }



        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (check3Frente.Checked == true && checkP.Checked == true) // Valor cobrado do para choque dianteiro (3) PINTURA
            {
                MessageBox.Show(av + Math.Round(cdt.Parachoque_Dianteiro_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check3Frente.Checked == true && checkCP.Checked == true) // Valor cobrado do para choque dianteiro (3) CARROCERIA / PINTURA
            {
                MessageBox.Show(av + Math.Round(cdt.Parachoque_Dianteiro_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor                
            }

            if (check2Frente.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira D/D - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor                
            }

            if (check2Frente.Checked == true && checkCP.Checked == true) // Valor cobrado da ponteira D/D - Carroceria / Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check4Frente.Checked == true && checkCP.Checked == true) // Valor cobrado da ponteira D/E - Carroceria / Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check4Frente.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira D/E - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor                
            }

            if (check1Frente.Checked == true && checkP.Checked == true) // Valor cobrado da grade dianteira - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Grade_Dianteira_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor     
            }

            if (check1Frente.Checked == true && checkCP.Checked == true) // Valor cobrado da grade dianteira - Carroceria Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Grade_Dianteira_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor     
            }


            // Traseira


            if (check2Tr.Checked == true && checkP.Checked == true) // Valor cobrado da traseira 2 PINTURA
            {
                MessageBox.Show(av + Math.Round(cdt.Traseira_Meio_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor  
            }

            if (check2Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da traseira 2 CARROCERIA PINTURA
            {
                MessageBox.Show(av + Math.Round(cdt.Traseira_Meio_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor  
            }

            if (check4Frente.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira D/E - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }


            if (check4Tr.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira traseira T/E - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_TD_TE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check1Tr.Checked == true && checkP.Checked == true) // Valor cobrado da coluna traseira 1 - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Coluna_TD_TE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check1Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da coluna traseira 1 - Carroceria / Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Coluna_TD_TE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check3Tr.Checked == true && checkP.Checked == true) // Valor cobrado da coluna traseira 3 - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Coluna_TD_TE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check3Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da coluna traseira 3 - Carroceria / Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Coluna_TD_TE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check4Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da ponteira traseira T/E - Carroceria / Pintura CHECK4
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_TD_TE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check5Tr.Checked == true && checkCP.Checked == true) // Valor cobrado do para choque traseiro CHECK 5 Recuperado
            {
                MessageBox.Show(av + Math.Round(cdt.Parachoque_Traseiro_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check6Tr.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira traseira T/D - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_TD_TE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check5Tr.Checked == true && checkP.Checked == true) // Valor cobrado do para choque traseiro Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Parachoque_Traseiro_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check6Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da ponteira traseira T/D Carroceria / pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_TD_TE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }






            // Lado Direito 1519

            if (check0LD.Checked == false && check1LD.Checked == true && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check1 selecionado
            {                                
                MessageBox.Show(av + Math.Round(c1519.total_check1_1519(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == true && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check2 selecionado
            {             
                MessageBox.Show(av + Math.Round(c1519.total_check2_1519(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == true && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check3 selecionado
            {
                MessageBox.Show(av + Math.Round(c1519.total_check3_1519(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == true && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check4 selecionado
            {

                total = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + seta + internorte + faixarefletiva;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }

            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == true && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check5 selecionado
            {

                total = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (nordem * 5) + faixarefletiva + seta;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }

            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == true && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check6 selecionado
            {

                total = (chapa75 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + peixinho;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }

             if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == true
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check7 selecionado
            {

                total = (chapa75 / 2) + (0.2 * chapelco) + (m60 * 0.10) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface);

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }


            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == true && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check8 selecionado
            {

                total = (chapa75 / 3) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + peixinho;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }


            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == true && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check9 selecionado
            {

                total = (chapa75 / 3) + (0.1 * chapelco) + (m60 * 0.05) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface);

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }

            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == true && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check10 selecionado
            {

                total = (chapa75 / 3) + (0.1 * chapelco) + (m60 * 0.05) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface);

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }

            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == true && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check10 selecionado
            {

                total = (chapa75 / 3) + (0.1 * chapelco) + (m60 * 0.05) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface);

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }



            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == true && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check11 selecionado
            {

                total = (chapa75 / 2) + (0.2 * chapelco) + (m60 * 0.10) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + peixinho;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }


            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == true
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check12 selecionado
            {

                total = (chapa75 / 2) + (0.2 * chapelco) + (m60 * 0.10) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (puxador * 2) + (trincot * 2);

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }



            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == true && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check13 selecionado
            {

                total = (chapa75 / 5) + (0.1 * chapelco) + (m60 * 0.10) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface);

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }


            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == true && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check14 selecionado
            {

                total = (chapa75 / 4) + (0.1 * chapelco) + (m60 * 0.10) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + peixao;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }

            // Lado Esquerdo 1519

if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == true && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check1 selecionado
            {

                total = (chapa90 / 3) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + capsula + (2 * faixarefletiva);

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }


            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == true
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check2 selecionado
            {

                total = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + capsula + faixarefletiva + (nordem * 6);

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }



            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == true && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check3 selecionado
            {

                total = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + internorte + faixarefletiva;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }


if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == true && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check4 selecionado
            {

                total = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + capsula + faixarefletiva;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor


            }



            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == true && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check5 selecionado
            {

                total = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + cadeirante + faixarefletiva;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }

            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == true && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check6 selecionado
            {

                total = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + cidadeRJ + faixarefletiva;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }



            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == true && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check7 selecionado
            {

                total = (chapa90 / 2) + (0.2 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + capsula + faixarefletiva;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor


            }


            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == true && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check8 selecionado
            {

                total = (chapa75 / 3) + (0.10 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (m60 * 0.5) + peixao;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor


            }


            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == true
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check9 selecionado
            {

                total = (chapa75 / 4) + (0.10 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (m60 * 0.5);

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor


            }


            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == true && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check10 selecionado
            {

                total = (chapa75 / 4) + (0.10 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (m60 * 0.5);

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor


            }
            
            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == true && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check11 selecionado
            {

                total = (chapa75 / 3) + (0.10 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (m60 * 0.5);

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor


            }


            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == true && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check12 selecionado
            {

                total = (chapa75 / 3) + (0.10 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (m60 * 0.10) + peixinho + puxador;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor


            }



            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == true && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check13 selecionado
            {

                total = (chapa75 / 2) + (0.10 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (m60 * 0.10) + peixinho + puxador;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor


            }




            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == true && check15LE.Checked == false && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check14 selecionado
            {

                total = (chapa75 / 3) + (0.10 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (m60 * 0.5) + peixao;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor


            }


            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == true && check16LE.Checked == false
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check15 selecionado
            {

                total = (chapa75 / 2) + (0.10 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + (m60 * 0.10);

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }



            if (check0LD.Checked == false && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false
                && check8LD.Checked == false && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false
                && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false
                && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false
                && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false && check9LE.Checked == false
                && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == true
                && check17LE.Checked == false && check18LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // Valor cobrado somente com Check16 selecionado
            {

                total = (chapa75 / 2) + (0.20 * chapelco) + (0.2 * washprimer) + (0.5 * catalizador) + (0.3 * papel) + (0.3 * fitagrossa) + (0.2 * duplaface) + peixinho;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }



            if (check0LD.Checked == true && check1LD.Checked == false && check2LD.Checked == false && check3LD.Checked == false && check4LD.Checked == false && check5LD.Checked == false && check6LD.Checked == false && check7LD.Checked == false && check8LD.Checked == false
             && check9LD.Checked == false && check10LD.Checked == false && check11LD.Checked == false && check12LD.Checked == false && check13LD.Checked == false && check14LD.Checked == false && check15LD.Checked == false && check16LD.Checked == false
             && check17LD.Checked == false && check1Frente.Checked == false && check2Frente.Checked == false
                && check3Frente.Checked == false && check4Frente.Checked == false && check1Tr.Checked == false && check2Tr.Checked == false && check3Tr.Checked == false && check4Tr.Checked == false && check5Tr.Checked == false && check6Tr.Checked == false && check1LE.Checked == false && check2LE.Checked == false && check3LE.Checked == false && check4LE.Checked == false && check5LE.Checked == false && check6LE.Checked == false && check7LE.Checked == false && check8LE.Checked == false
             && check9LE.Checked == false && check10LE.Checked == false && check11LE.Checked == false && check12LE.Checked == false && check13LE.Checked == false && check14LE.Checked == false && check15LE.Checked == false && check16LE.Checked == false && check17LE.Checked == false
             && check18LE.Checked == false && check19LE.Checked == false && checkCP.Checked == true && checkP.Checked == false && txtModelo.Text.Equals("1519")) // coluna traseira esquerda CARROCERIA / PINTURA
            {
                total = (massafibra / 2) + (massapoliester / 2) + (m60 * 0.20) + faixarefletiva + (2 * disco80) + (papel / 2) + fitafina + (redutor * 0.05) + faixarefletiva;

                MessageBox.Show(av + total.ToString("F2"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }
        }


        private void btn2LD_CheckedChanged(object sender, EventArgs e) // Radio Button Lado Direito
        {

            if (rbLD.Checked == true && txtModelo.Text.Equals("1722")) // Se o Lado Direito estiver marcado e o modelo do carro for 1722 quando apertar enter muda a foto para Lado Direito do 1722 
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1722; // Se o Lado Direito estiver marcado e o modelo for 1722 altera a imagem
            }           

            if (rbLD.Checked == true && txtModelo.Text.Equals("1519"))
            {

                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Lourdes; //Se a traseira estiver macada e o modelo for 1519 a foto muda para 1519
            }


            if (rbLD.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Se o lado direito estiver marcado e o modelo de carro for ar condicionado quando apertar enter a foto muda para direita do ar condicionado
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Ar_condicionado1;
            }

            // =============== Dianteira =================== 

            foreach (Component Controls in pnlCheckFrente.Controls)
            {
                (Controls as CheckBox).Checked = false; // Desmarca todas as checkbox da traseira
            }

            pnlCheckFrente.Visible = false; // Desativa a visibilidade do painel com os check da dianteira           


            // =============== Lado Esquerdo ===================                                            

            foreach (Component Controls in pnlCheckLE.Controls)
            {
                (Controls as CheckBox).Checked = false; // Desmarca todas as checkbox do lado direito
            }

            pnlCheckLE.Visible = false; // Desativa o painel com os Checks do Lado Esquerdo


            // =============== Traseira ===================

            foreach (Component Controls in pnlCheckTraseira.Controls)
            {
                (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox da traseira
            }

            pnlCheckTraseira.Visible = false; // Desativa a visibilidade com os check da traseira

        }

        private void rbLE_CheckedChanged(object sender, EventArgs e) // Radio Button lado esquerdo
        {
            if (rbLE.Checked == true && txtModelo.Text.Equals("1722")) // Se o número de ordem for modelo 1722 e o lado esquerdo estiver selecionado altera a imagem para 1722
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1722; // Se o Lado Direito estiver marcado e o modelo for 1722 altera a imagem
            }

            if (rbLE.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Se o número de ordem for modelo Ar condicionado e o lado esquerdo estiver selecionado altera a imagem para Ar condicionado
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Ar_condicionado1; // Esquerda Sem número

                
            }

            if(rbLE.Checked == true && txtModelo.Text.Equals("1519"))
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Lourdes; // Esquerda Sem número
            }


            if (rbLE.Checked == true) // Quando Lado esquerdo estiver marcado 
            {

                // =============== Dianteira =================== 

                foreach (Component Controls in pnlCheckFrente.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todas as checkbox da traseira
                }

                pnlCheckFrente.Visible = false; // Desativa a visibilidade do painel com os check da dianteira


                // =============== Lado direito ===================                                            

                foreach (Component Controls in pnlCheckLD.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todas as checkbox do lado direito
                }

                pnlCheckLD.Visible = false; // Desativa o painel com os Checks do Lado Direito                


                // =============== Traseira ===================

                foreach (Component Controls in pnlCheckTraseira.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox da traseira
                }

                pnlCheckTraseira.Visible = false; // Desativa a visibilidade com os check da traseira

            }
        }

        private void rbDianteira_CheckedChanged(object sender, EventArgs e) // Radio button Dianteira
        {

            if (rbDianteira.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Se a frente estiver marcada e o modelo de carro for ar condicionado quando apertar enter a foto muda para frente do ar condicionado
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Ar_condicionado1; // Frente ar condiconado sem numero

                            
            }

            if (rbDianteira.Checked == true && txtModelo.Text.Equals("1722")) // Se a frente estiver marcada e o modelo do carro for 1722 quando apertar enter muda a foto para frente do 1722 
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1722; // Se a frente estiver marcada e o modelo for 1722 altera a imagem
            }            

            if(rbDianteira.Checked == true && txtModelo.Text.Equals("1519"))
            {

                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Lourdes; // Se a dianteira estiver marcada e o modelo for 1519 a foto muda para 1519
            }


            // =============== Traseira ===================

            foreach (Component Controls in pnlCheckTraseira.Controls)
            {
                (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox da traseira
            }

            pnlCheckTraseira.Visible = false; // Desativa a visibilidade com os check da traseira

            // =============== Lado direito ===================

            foreach (Component Controls in pnlCheckLD.Controls)
            {
                (Controls as CheckBox).Checked = false; //Desmarca todas as check box do Lado Direito

            }


            pnlCheckLD.Visible = false;

            // =============== Lado Esquerdo =======================

            foreach (Component Controls in pnlCheckLE.Controls)
            {
                (Controls as CheckBox).Checked = false; // Desmarca todas as checkbox do Lado Esquerdo

            }

            pnlCheckLE.Visible = false; // Desativa a visibilidade do painel com os check do Lado Esquerdo
        }


        private void checkCP_CheckedChanged(object sender, EventArgs e)
        {

            if (checkCP.Checked == true) // Se o check Carroceria Pintura estiver marcado o check de Pintura fica desabilitado
            {
                checkP.Enabled = false; // Desativa o check de pintura

            }

            else
            {
                checkP.Enabled = true; // Senão o check de pintura fica habilitado 
            }

        }

        private void checkP_CheckedChanged(object sender, EventArgs e)
        {
            if (checkP.Checked == true) // Quando o tipo de avaria PINTURA estiver marcado o tipo de avaria carroceria e pintura ficar desabilitado
            {
                checkCP.Enabled = false; // Desativa o check Carroceria e pintura

            }

            else
            {
                checkCP.Enabled = true; // Senão o check de carroceria pintura fica habilitado 
            }

        }

        private void rbTraseira_CheckedChanged(object sender, EventArgs e)
        {

            if (rbTraseira.Checked == true && txtModelo.Text.Equals("1722")) // Se a traseira estiver marcada e o modelo do carro for 1722 quando apertar enter muda a foto para traseira do 1722 
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1722; // Se a traseira estiver marcada e o modelo for 1722 altera a imagem
            }

            if (rbTraseira.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Se a traseira estiver marcada e o modelo de carro for ar condicionado quando apertar enter a foto muda para traseira do ar condicionado)
            {
                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Ar_condicionado1; // Se o a traseira estiver marcada e o modelo for Ar condicionado altera a imagem
                
            }

            if(rbTraseira.Checked == true && txtModelo.Text.Equals("1519"))
            {

                AvariaAR.ActiveForm.BackgroundImage = global::Empresa2.Properties.Resources._1519Lourdes; //Se a traseira estiver macada e o modelo for 1519 a foto muda para 1519
            }

            if (rbTraseira.Checked == true)
            {

                // =============== Lado direito ===================

                foreach (Component Controls in pnlCheckLD.Controls)
                {
                    (Controls as CheckBox).Checked = false;
                }


                pnlCheckLD.Visible = false; // Desativa a vibilidade  do painel com os Check do Lado Direito


                // =============== Lado Esquerdo =======================

                foreach (Component Controls in pnlCheckLE.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox do lado esquerdo
                }


                pnlCheckLE.Visible = false; //Desativa a visibilidade do painel com os Check Lado Esquerdo


                // =============== Dianteira =======================

                foreach (Component Controls in pnlCheckFrente.Controls)
                {
                    (Controls as CheckBox).Checked = false; // Desmarca todos os checkbox da dianteira
                }

                pnlCheckFrente.Visible = false; // Desativa o painel com os check da dianteira

            }
        }

       

        private void label2_Click(object sender, EventArgs e)
        {
            AvariaAR.ActiveForm.Close();
        }

        private void btnCalcular1722_Click(object sender, EventArgs e)
        {
            if (check3Frente.Checked == true && checkP.Checked == true) // Valor cobrado do para choque dianteiro (3) PINTURA
            {
                MessageBox.Show(av + Math.Round(cdt.Parachoque_Dianteiro_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check3Frente.Checked == true && checkCP.Checked == true) // Valor cobrado do para choque dianteiro (3) CARROCERIA / PINTURA
            {
                MessageBox.Show(av + Math.Round(cdt.Parachoque_Dianteiro_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor                
            }

            if (check2Frente.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira D/D - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor                
            }

            if (check2Frente.Checked == true && checkCP.Checked == true) // Valor cobrado da ponteira D/D - Carroceria / Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check4Frente.Checked == true && checkCP.Checked == true) // Valor cobrado da ponteira D/E - Carroceria / Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check4Frente.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira D/E - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor                
            }

            if (check1Frente.Checked == true && checkP.Checked == true) // Valor cobrado da grade dianteira - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Grade_Dianteira_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor     
            }

            if (check1Frente.Checked == true && checkCP.Checked == true) // Valor cobrado da grade dianteira - Carroceria Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Grade_Dianteira_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor     
            }


            // Traseira


            if (check2Tr.Checked == true && checkP.Checked == true) // Valor cobrado da traseira 2 PINTURA
            {
                MessageBox.Show(av + Math.Round(cdt.Traseira_Meio_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor  
            }

            if (check2Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da traseira 2 CARROCERIA PINTURA
            {
                MessageBox.Show(av + Math.Round(cdt.Traseira_Meio_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor  
            }

            if (check4Frente.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira D/E - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }


            if (check4Tr.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira traseira T/E - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_TD_TE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check1Tr.Checked == true && checkP.Checked == true) // Valor cobrado da coluna traseira 1 - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Coluna_TD_TE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check1Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da coluna traseira 1 - Carroceria / Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Coluna_TD_TE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check3Tr.Checked == true && checkP.Checked == true) // Valor cobrado da coluna traseira 3 - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Coluna_TD_TE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check3Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da coluna traseira 3 - Carroceria / Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Coluna_TD_TE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check4Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da ponteira traseira T/E - Carroceria / Pintura CHECK4
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_TD_TE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check5Tr.Checked == true && checkCP.Checked == true) // Valor cobrado do para choque traseiro CHECK 5 Recuperado
            {
                MessageBox.Show(av + Math.Round(cdt.Parachoque_Traseiro_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check6Tr.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira traseira T/D - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_TD_TE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check5Tr.Checked == true && checkP.Checked == true) // Valor cobrado do para choque traseiro Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Parachoque_Traseiro_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check6Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da ponteira traseira T/D Carroceria / pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_TD_TE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }


            // Lado Direito 1722

            if (check0LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado coluna traseira direita CARROCERIA / PINTURA
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check0_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check1LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com Check1 selecionado
            {
               MessageBox.Show(av + Math.Round(c1722.total_check1_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check2LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com Check2 selecionado
            {                
                MessageBox.Show(av + Math.Round(c1722.total_check2_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check3LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com Check3 selecionado
            {              
                MessageBox.Show(av + Math.Round(c1722.total_check3_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check4LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com Check4 selecionado
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check4_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check5LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com Check5 selecionado
            {                
                MessageBox.Show(av + Math.Round(c1722.total_check5_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check6LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com Check6 selecionado
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check6_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }        

            if (check7LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check7 selecionado
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check7_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }


            if (check8LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check8 selecionado
            {             
                MessageBox.Show(av + Math.Round(c1722.total_check8_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check9LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check9 Lado Direito selecionado
            {                
                MessageBox.Show(av + Math.Round(c1722.total_check9_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check10LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check10 selecionado
            {             
                MessageBox.Show(av + Math.Round(c1722.total_check10_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check11LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check11 selecionado
            {
                MessageBox.Show(av + Math.Round(c1722.total_check11_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check12LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check12 selecionado
            {
                MessageBox.Show(av + Math.Round(c1722.total_check12_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check13LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check13 selecionado
            {
                MessageBox.Show(av + Math.Round(c1722.total_check13_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check14LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check14 selecionado
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check14_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check15LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check15 selecionado
            {                
                MessageBox.Show(av + Math.Round(c1722.total_check15_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }


            if (check16LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check16 selecionado
            {              
                MessageBox.Show(av + Math.Round(c1722.total_check16_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check17LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check17 selecionado
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check17_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            // Lado Esquerdo 1722
           

            if (check1LE.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check1 Lado Esquerdo
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check1LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check2LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check2 Lado Esquerdo
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check2LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check3LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check3 Lado Esquerdo
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check3LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check4LE.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check17 selecionado // Valor cobrado somente com o check4 Lado Esquerdo
            {
                MessageBox.Show(av + Math.Round(c1722.total_check4LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check5LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check5 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(c1722.total_check5LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check6LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check6 Lado Esquerdo
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check6LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check7LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check7 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(c1722.total_check7LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check8LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check8 Lado Esquerdo
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check8LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }


            if (check9LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check9 Lado Esquerdo
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check9LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }


            if (check10LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check10 Lado Esquerdo
            {              
                MessageBox.Show(av + Math.Round(c1722.total_check10LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check11LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check11 Lado Esquerdo
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check11LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check12LE.Checked == true  && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check12 Lado Esquerdo
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check12LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check13LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check13 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(c1722.total_check13LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor

            }

            if (check14LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check14 Lado Esquerdo
            {
                MessageBox.Show(av + Math.Round(c1722.total_check14LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check15LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check15 Lado Esquerdo
            {               
                MessageBox.Show(av + Math.Round(c1722.total_check15LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check16LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check16 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(c1722.total_check16LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check17LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check17 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(c1722.total_check17LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check18LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check18 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(c1722.total_check18LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }             

           if (check19LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("1722")) // Valor cobrado somente com o check19 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(c1722.total_check19LE_1722(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            } 


        }

        private void AvariaAR_Load(object sender, EventArgs e)
        {          

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            if (check3Frente.Checked == true && checkP.Checked == true) // Valor cobrado do para choque dianteiro (3) PINTURA
            {            
                MessageBox.Show(av + Math.Round(cdt.Parachoque_Dianteiro_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check3Frente.Checked == true && checkCP.Checked == true) // Valor cobrado do para choque dianteiro (3) CARROCERIA / PINTURA
            {              
                MessageBox.Show(av + Math.Round(cdt.Parachoque_Dianteiro_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor                
            }

            if (check2Frente.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira D/D - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor                
            }

            if (check2Frente.Checked == true && checkCP.Checked == true) // Valor cobrado da ponteira D/D - Carroceria / Pintura
            {              
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check4Frente.Checked == true && checkCP.Checked == true) // Valor cobrado da ponteira D/E - Carroceria / Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check4Frente.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira D/E - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor                
            }

            if (check1Frente.Checked == true && checkP.Checked == true) // Valor cobrado da grade dianteira - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Grade_Dianteira_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor     
            }

            if (check1Frente.Checked == true && checkCP.Checked == true) // Valor cobrado da grade dianteira - Carroceria Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Grade_Dianteira_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor     
            }


            // Traseira


            if (check2Tr.Checked == true && checkP.Checked == true) // Valor cobrado da traseira 2 PINTURA
            {
                MessageBox.Show(av + Math.Round(cdt.Traseira_Meio_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor  
            }

            if (check2Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da traseira 2 CARROCERIA PINTURA
            {
                MessageBox.Show(av + Math.Round(cdt.Traseira_Meio_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor  
            }

            if (check4Frente.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira D/E - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_DD_DE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }


            if (check4Tr.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira traseira T/E - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_TD_TE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check1Tr.Checked == true && checkP.Checked == true) // Valor cobrado da coluna traseira 1 - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Coluna_TD_TE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check1Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da coluna traseira 1 - Carroceria / Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Coluna_TD_TE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check3Tr.Checked == true && checkP.Checked == true) // Valor cobrado da coluna traseira 3 - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Coluna_TD_TE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check3Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da coluna traseira 3 - Carroceria / Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Coluna_TD_TE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check4Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da ponteira traseira T/E - Carroceria / Pintura CHECK4
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_TD_TE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check5Tr.Checked == true && checkCP.Checked == true) // Valor cobrado do para choque traseiro CHECK 5 Recuperado
            {
                MessageBox.Show(av + Math.Round(cdt.Parachoque_Traseiro_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check6Tr.Checked == true && checkP.Checked == true) // Valor cobrado da ponteira traseira T/D - Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_TD_TE_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check5Tr.Checked == true && checkP.Checked == true) // Valor cobrado do para choque traseiro Pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Parachoque_Traseiro_P(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check6Tr.Checked == true && checkCP.Checked == true) // Valor cobrado da ponteira traseira T/D Carroceria / pintura
            {
                MessageBox.Show(av + Math.Round(cdt.Ponteira_TD_TE_CP(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }


            // Lado Esquerdo Ar condiconado


            if (check1LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check1 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check1LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check2LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check2 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check2LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check3LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check3 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check3LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check4LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check4 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check4LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check5LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check5 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check5LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check6LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check6 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check6LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check7LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check7 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check7LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check8LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check8 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check8LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check9LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check9 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check9LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check10LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check10 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check10LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check11LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check11 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check11LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check12LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check12 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check12LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check13LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check13 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check13LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check14LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check14 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check14LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check15LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check15 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check15LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check16LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check16 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check16LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check17LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check17 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check17LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            if (check18LE.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check18 Lado Esquerdo
            {                
                MessageBox.Show(av + Math.Round(car.total_check18LE_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }

            // Lado Direito Ar condiconado            

            if (check0LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check0 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check0_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }            

            if (check1LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check1 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check1_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }            

            if (check2LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check2 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check2_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }            

            if (check3LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check3 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check3_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }            

            if (check4LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check4 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check4_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }          

            if (check5LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check5 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check5_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }            

            if (check6LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check6 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check6_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }          
           
            if (check7LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check7 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check7_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }            
            
            if (check8LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check8 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check8_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }          

            if (check9LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check9 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check9_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }            

            if (check10LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check10 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check10_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }            

            if (check11LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check11 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check11_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            }            

            if (check12LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check12 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check12_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            } 

            if (check13LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check13 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check13_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            } 

            if (check14LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check14 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check14_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            } 

            if (check15LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check15 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check15_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            } 

            if (check16LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check16 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check16_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            } 

            if (check17LD.Checked == true && checkCP.Checked == true && txtModelo.Text.Equals("Ar condicionado")) // Valor cobrado somente com o check17 Lado Direito
            {              
                MessageBox.Show(av + Math.Round(car.total_check17_ArCondicionado(), 2), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); // Caixa de mensagem com o valor
            } 
        }

        private void btnPesquisarAvaria_Click(object sender, EventArgs e)
        {
            PesquisarAV pesav = new PesquisarAV();

            pesav.ShowDialog();
        }

        private void combNordem_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (combNordem.SelectedItem.Equals("58001") || combNordem.SelectedItem.Equals("58003") || combNordem.SelectedItem.Equals("58011") || combNordem.SelectedItem.Equals("58014") || combNordem.SelectedItem.Equals("58019") || combNordem.SelectedItem.Equals("58020") || combNordem.SelectedItem.Equals("58023")
                || combNordem.SelectedItem.Equals("58023") || combNordem.SelectedItem.Equals("58033") || combNordem.SelectedItem.Equals("58042") || combNordem.SelectedItem.Equals("58049") || combNordem.SelectedItem.Equals("58053") || combNordem.SelectedItem.Equals("58054") || combNordem.SelectedItem.Equals("58061")
                || combNordem.SelectedItem.Equals("58065") || combNordem.SelectedItem.Equals("58070") || combNordem.SelectedItem.Equals("58073") || combNordem.SelectedItem.Equals("58077") || combNordem.SelectedItem.Equals("58078") || combNordem.SelectedItem.Equals("58079") || combNordem.SelectedItem.Equals("58089")
                || combNordem.SelectedItem.Equals("58091") || combNordem.SelectedItem.Equals("58092") || combNordem.SelectedItem.Equals("58098") || combNordem.SelectedItem.Equals("58102") || combNordem.SelectedItem.Equals("58110") || combNordem.SelectedItem.Equals("58111") || combNordem.SelectedItem.Equals("58118")
                || combNordem.SelectedItem.Equals("58122") || combNordem.SelectedItem.Equals("58131") || combNordem.SelectedItem.Equals("58132") || combNordem.SelectedItem.Equals("58135") || combNordem.SelectedItem.Equals("58150") || combNordem.SelectedItem.Equals("58152") || combNordem.SelectedItem.Equals("58153")
                || combNordem.SelectedItem.Equals("58155") || combNordem.SelectedItem.Equals("58157") || combNordem.SelectedItem.Equals("58160") || combNordem.SelectedItem.Equals("58161") || combNordem.SelectedItem.Equals("58162") || combNordem.SelectedItem.Equals("58163") || combNordem.SelectedItem.Equals("58164")
                || combNordem.SelectedItem.Equals("58165") || combNordem.SelectedItem.Equals("58166") || combNordem.SelectedItem.Equals("58174")) // Modelo de carros 1722
            {
                txtModelo.Text = "1722";
            }

            if (combNordem.SelectedItem.Equals("58009") || combNordem.SelectedItem.Equals("58016") || combNordem.SelectedItem.Equals("58017") || combNordem.SelectedItem.Equals("58028") || combNordem.SelectedItem.Equals("58031") || combNordem.SelectedItem.Equals("58058") || combNordem.SelectedItem.Equals("58060")
            || combNordem.SelectedItem.Equals("58081") || combNordem.SelectedItem.Equals("58088") || combNordem.SelectedItem.Equals("58100") || combNordem.SelectedItem.Equals("58103") || combNordem.SelectedItem.Equals("58106") || combNordem.SelectedItem.Equals("58113") || combNordem.SelectedItem.Equals("58114")
            || combNordem.SelectedItem.Equals("58115") || combNordem.SelectedItem.Equals("58116") || combNordem.SelectedItem.Equals("58120") || combNordem.SelectedItem.Equals("58121") || combNordem.SelectedItem.Equals("58125") || combNordem.SelectedItem.Equals("58147") || combNordem.SelectedItem.Equals("58172")
            || combNordem.SelectedItem.Equals("58177") || combNordem.SelectedItem.Equals("58178") || combNordem.SelectedItem.Equals("58185") || combNordem.SelectedItem.Equals("58188") || combNordem.SelectedItem.Equals("58190") || combNordem.SelectedItem.Equals("58204") || combNordem.SelectedItem.Equals("58205")
            || combNordem.SelectedItem.Equals("58207") || combNordem.SelectedItem.Equals("58210") || combNordem.SelectedItem.Equals("58211") || combNordem.SelectedItem.Equals("58214") || combNordem.SelectedItem.Equals("58215") || combNordem.SelectedItem.Equals("58216") || combNordem.SelectedItem.Equals("58217")) //Modelo de carro Ar condicionado

            {
                txtModelo.Text = "Ar condicionado";
            }

            if (combNordem.SelectedItem.Equals("58006") || combNordem.SelectedItem.Equals("58007") || combNordem.SelectedItem.Equals("58008") || combNordem.SelectedItem.Equals("58010") || combNordem.SelectedItem.Equals("58012") || combNordem.SelectedItem.Equals("58013") || combNordem.SelectedItem.Equals("58022")
                || combNordem.SelectedItem.Equals("58024") || combNordem.SelectedItem.Equals("58025") || combNordem.SelectedItem.Equals("58027") || combNordem.SelectedItem.Equals("58032") || combNordem.SelectedItem.Equals("58034") || combNordem.SelectedItem.Equals("58035") || combNordem.SelectedItem.Equals("58039")
                || combNordem.SelectedItem.Equals("58040") || combNordem.SelectedItem.Equals("58043") || combNordem.SelectedItem.Equals("58044") || combNordem.SelectedItem.Equals("58046") || combNordem.SelectedItem.Equals("58047") || combNordem.SelectedItem.Equals("58048") || combNordem.SelectedItem.Equals("58052")
                || combNordem.SelectedItem.Equals("58055") || combNordem.SelectedItem.Equals("58056") || combNordem.SelectedItem.Equals("58059") || combNordem.SelectedItem.Equals("58094") || combNordem.SelectedItem.Equals("58095") || combNordem.SelectedItem.Equals("58096") || combNordem.SelectedItem.Equals("58097")
                || combNordem.SelectedItem.Equals("58105") || combNordem.SelectedItem.Equals("58117") || combNordem.SelectedItem.Equals("58119") || combNordem.SelectedItem.Equals("58123") || combNordem.SelectedItem.Equals("58124") || combNordem.SelectedItem.Equals("58127") || combNordem.SelectedItem.Equals("58128")
                || combNordem.SelectedItem.Equals("58151") || combNordem.SelectedItem.Equals("58167") || combNordem.SelectedItem.Equals("58168") || combNordem.SelectedItem.Equals("58169") || combNordem.SelectedItem.Equals("58171") || combNordem.SelectedItem.Equals("58173") || combNordem.SelectedItem.Equals("58189")) // Modelo de carros 1519
            {
                txtModelo.Text = "1519";
            }
        }
    }
}

       